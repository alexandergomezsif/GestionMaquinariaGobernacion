import re

with open('js/modules/frentes.js', 'r', encoding='utf-8') as f:
    text = f.read()

old_logic = """          id: window.AppHelpers.generateUUID(),
          municipality: item.municipio,
          name: item.frente,
          date: window.AppHelpers.getFormattedCurrentDate(),
          metadata: frenteMetadata[key] || { estadoVia: '', avance: '', longitud: '', km: '' },
          equipment: []"""

new_logic = """          id: window.AppHelpers.generateUUID(),
          municipality: item.municipio,
          name: item.frente,
          date: window.AppHelpers.getFormattedCurrentDate(),
          metadata: frenteMetadata[key] || { estadoVia: '', avance: '', longitud: '', km: '' },
          activityType: frenteMetadata[key] ? frenteMetadata[key].activityType : 'Emergencias Viales',
          equipment: []"""

if old_logic in text:
    text = text.replace(old_logic, new_logic)
    with open('js/modules/frentes.js', 'w', encoding='utf-8') as f:
        f.write(text)
    print("Patched activityType propagation")
else:
    print("Failed to find logic block")
