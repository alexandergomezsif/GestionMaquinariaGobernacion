import re

with open('js/modules/frentes.js', 'r', encoding='utf-8') as f:
    text = f.read()

# Restore renderFrenteCard to its original structure but with the new icons
render_card_pattern = re.compile(r'function renderFrenteCard\(frente\) \{.*?(?=\s*function processCSVImport)', re.DOTALL)

new_render_card = """function renderFrenteCard(frente) {
    const eqPropios = frente.equipment.filter(e => (e.owner || '').toLowerCase().includes('gobernaci') || (e.owner || '').toLowerCase().includes('propio'));
    const eqRentan = frente.equipment.filter(e => (e.owner || '').toLowerCase().includes('rentan'));
    const eqAlquilados = frente.equipment.filter(e => !(e.owner || '').toLowerCase().includes('gobernaci') && !(e.owner || '').toLowerCase().includes('propio') && !(e.owner || '').toLowerCase().includes('rentan'));

    const actType = frente.activityType || 'Emergencias Viales';
    const actIcon = actType === 'Emergencias Viales' ? 'icono-emergencias.png' : 'icono-puntos.png';
    const actColor = actType === 'Emergencias Viales' ? '#dc2626' : '#ca8a04';

    // Agrupar equipos por nombre para los iconos superiores
    const eqGroups = {};
    frente.equipment.forEach(e => {
        const type = window.AppHelpers.escapeHTML(e.type);
        if(!eqGroups[type]) eqGroups[type] = 0;
        eqGroups[type]++;
    });
    
    let eqSummaryHtml = '<div style="display:flex; flex-wrap:wrap; gap:8px; margin-top: 10px; margin-bottom: 5px;">';
    for(const [type, count] of Object.entries(eqGroups)) {
        eqSummaryHtml += `
            <div style="display:flex; align-items:center; background:#f1f5f9; padding:3px 6px; border-radius:4px; border:1px solid #e2e8f0;" title="${type}">
                ${window.AppHelpers.getEquipmentIcon(type, 18)} 
                <span style="font-weight:bold; font-size:0.8rem; color:var(--primary-dark);">x${count}</span>
            </div>
        `;
    }
    eqSummaryHtml += '</div>';

    return `
      <div class="card" style="display: flex; flex-direction: column; box-shadow: var(--shadow-md);">
        <div style="border-bottom: 2px solid var(--card-border); padding-bottom: 10px; margin-bottom: 10px;">
          <!-- Badge de Actividad -->
          <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 8px;">
            <div style="display:flex; align-items:center; background:${actColor}15; color:${actColor}; padding:2px 8px; border-radius:12px; font-weight:bold; font-size:0.75rem; text-transform:uppercase;">
                <img src="img/${actIcon}" style="width:16px; height:16px; margin-right:6px; object-fit:contain;" alt="Icon">
                ${actType}
            </div>
            <span style="background: #f1f5f9; color: #475569; padding: 2px 6px; border-radius: 4px; font-size: 0.7rem; font-weight: bold;">
              ${frente.date || window.AppHelpers.getFormattedCurrentDate()}
            </span>
          </div>

          <div style="display:flex; justify-content:space-between; align-items:flex-start;">
            <h3 style="margin: 0; color: var(--primary-dark); font-size: 1.1rem; line-height: 1.2;">
              📍 ${window.AppHelpers.escapeHTML(frente.municipality)}
            </h3>
          </div>
          <div style="font-size: 0.9rem; color: var(--text-secondary); margin-top: 4px; font-weight: 500;">
            ${window.AppHelpers.escapeHTML(frente.name)}
          </div>
          
          ${eqSummaryHtml}
          
          ${frente.metadata && (frente.metadata.estadoVia || frente.metadata.avance || frente.metadata.longitud || frente.metadata.km) ? `
          <div style="background: #f8fafc; border-radius: 4px; padding: 8px; margin-top: 8px; font-size: 0.75rem; color: var(--text-secondary);">
            ${frente.metadata.estadoVia ? `<div style="margin-bottom:2px;"><strong>🛣️ Estado:</strong> ${window.AppHelpers.escapeHTML(frente.metadata.estadoVia)}</div>` : ''}
            ${frente.metadata.avance ? `<div style="margin-bottom:2px;"><strong>📈 Avance:</strong> ${window.AppHelpers.escapeHTML(frente.metadata.avance)}</div>` : ''}
            ${frente.metadata.longitud ? `<div style="margin-bottom:2px;"><strong>📏 Longitud:</strong> ${window.AppHelpers.escapeHTML(frente.metadata.longitud)}</div>` : ''}
            ${frente.metadata.km ? `<div><strong>📍 Km Atención:</strong> ${window.AppHelpers.escapeHTML(frente.metadata.km)}</div>` : ''}
          </div>
          ` : ''}
        </div>

        <div style="flex-grow: 1;">
          <div style="display:flex; justify-content:space-between; font-size: 0.75rem; font-weight: bold; margin-bottom: 8px; color: var(--text-muted);">
            <span>TOTAL EQUIPOS: ${frente.equipment.length}</span>
            <span>
              ${eqPropios.length > 0 ? `<span style="color: var(--primary-green);">${eqPropios.length} GOB</span>` : ''} 
              ${eqPropios.length > 0 && (eqRentan.length > 0 || eqAlquilados.length > 0) ? ' | ' : ''}
              ${eqRentan.length > 0 ? `<span style="color: var(--status-info);">${eqRentan.length} RNT</span>` : ''}
              ${eqRentan.length > 0 && eqAlquilados.length > 0 ? ' | ' : ''}
              ${eqAlquilados.length > 0 ? `<span style="color: #f59e0b;">${eqAlquilados.length} ALQ</span>` : ''}
            </span>
          </div>

          <ul style="list-style: none; padding: 0; margin: 0; display:flex; flex-direction:column; gap:6px;">
            ${frente.equipment.map(eq => {
              const ownerLower = (eq.owner || '').toLowerCase();
              const isGobernacion = ownerLower.includes('gobernaci') || ownerLower.includes('propio');
              const isRentan = ownerLower.includes('rentan');
              let tagColor = '#f59e0b';
              let ownerInitials = 'ALQ';
              if(isGobernacion) { tagColor = 'var(--primary-green)'; ownerInitials = 'GOB'; }
              else if(isRentan) { tagColor = 'var(--status-info)'; ownerInitials = 'RNT'; }

              return `
                <li style="display:flex; justify-content:space-between; align-items:center; background: #ffffff; padding: 6px 8px; border-radius: 4px; border-left: 3px solid ${tagColor}; border: 1px solid var(--card-border);">
                  <div style="display:flex; flex-direction:column; overflow:hidden;">
                    <span style="font-size: 0.75rem; font-weight: 700; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; color: var(--primary-dark);" title="${window.AppHelpers.escapeHTML(eq.type)}">
                      ${window.AppHelpers.getEquipmentIcon(eq.type)} ${window.AppHelpers.escapeHTML(eq.type)}
                    </span>
                    <span style="font-size: 0.7rem; color: var(--text-muted); margin-top: 1px;">Placa/Id: ${window.AppHelpers.escapeHTML(eq.plate || 'N/A')}</span>
                  </div>
                  <div style="display:flex; flex-direction:column; align-items:flex-end;">
                    <span style="font-size: 0.65rem; background: ${tagColor}; color: white; padding: 2px 4px; border-radius: 3px; font-weight:bold;">
                      ${ownerInitials}
                    </span>
                    <span style="font-size: 0.65rem; margin-top:2px; color: ${eq.status.toLowerCase().includes('operativo') ? 'var(--status-success)' : 'var(--status-danger)'};">
                      ${window.AppHelpers.escapeHTML(eq.status)}
                    </span>
                  </div>
                </li>
              `;
            }).join('')}
          </ul>
        </div>
      </div>
    `;
  }"""

text = re.sub(render_card_pattern, new_render_card + '\n\n  ', text)


# Now fix sorting:
frentes_render_start = """    let frentesToRender = state.frentesActivos || [];"""
frentes_render_new = """    let frentesToRender = state.frentesActivos || [];
    
    // Organizar: Primero Emergencias, luego Puntos Críticos
    frentesToRender.sort((a, b) => {
        const typeA = a.activityType || 'Emergencias Viales';
        const typeB = b.activityType || 'Emergencias Viales';
        if (typeA === 'Emergencias Viales' && typeB !== 'Emergencias Viales') return -1;
        if (typeA !== 'Emergencias Viales' && typeB === 'Emergencias Viales') return 1;
        return 0;
    });"""

if frentes_render_start in text:
    text = text.replace(frentes_render_start, frentes_render_new)

with open('js/modules/frentes.js', 'w', encoding='utf-8') as f:
    f.write(text)

print("frentes.js patched")
