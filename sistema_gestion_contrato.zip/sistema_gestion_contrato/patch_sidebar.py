import sys
content = open('index.html', 'r', encoding='utf-8').read()
idx = content.find('data-module="informes"')
if idx > 0:
    end_idx = content.find('</li>', idx) + 5
    new_item = '\n        <li class="nav-item">\n          <a href="#" class="nav-link" data-module="frentesActivos">\n            <span class="nav-icon">🚧</span> Frentes Activos\n          </a>\n        </li>'
    new_content = content[:end_idx] + new_item + content[end_idx:]
    open('index.html', 'w', encoding='utf-8').write(new_content)
    print('Injected successfully!')
else:
    print('Informes not found')
