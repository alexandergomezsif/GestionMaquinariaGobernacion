import sys

with open('js/modules/frentes.js', 'r', encoding='utf-8') as f:
    text = f.read()

# using a simpler replace
old_part_1 = "el.style.backgroundColor = 'var(--primary-dark)';"
new_part_1 = "el.style.backgroundColor = 'white';"

old_part_2 = "el.style.border = '2px solid white';"
new_part_2 = "el.style.border = '2px solid var(--primary-dark)';"

old_part_3 = "el.innerHTML = '<i class=\"ti ti-backhoe\"></i>';"
new_part_3 = "el.innerHTML = '<img src=\"img/excavator.png\" style=\"width:18px; height:18px; object-fit:contain;\" alt=\"Frente\">';"

text = text.replace(old_part_1, new_part_1)
text = text.replace(old_part_2, new_part_2)
text = text.replace(old_part_3, new_part_3)

with open('js/modules/frentes.js', 'w', encoding='utf-8') as f:
    f.write(text)
print("Replaced!")
