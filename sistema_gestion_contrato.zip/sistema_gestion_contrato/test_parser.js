const fs = require('fs');

const csvText = fs.readFileSync('../.user_uploaded/media__1785442623753.csv', 'utf8');

  function processCSVImport(csvText) {
    const delimiter = csvText.split(/[\r\n]+/)[0].includes(';') ? ';' : ',';
    const rows = [];
    let currentRow = [];
    let currentCell = '';
    let inQuotes = false;

    for (let i = 0; i < csvText.length; i++) {
      const char = csvText[i];
      const nextChar = csvText[i+1];

      if (inQuotes) {
        if (char === '"' && nextChar === '"') {
          currentCell += '"';
          i++; 
        } else if (char === '"') {
          inQuotes = false;
        } else {
          currentCell += char;
        }
      } else {
        if (char === '"') {
          inQuotes = true;
        } else if (char === delimiter) {
          currentRow.push(currentCell.trim());
          currentCell = '';
        } else if (char === '\n' || (char === '\r' && nextChar === '\n')) {
          currentRow.push(currentCell.trim());
          rows.push(currentRow);
          currentRow = [];
          currentCell = '';
          if (char === '\r') i++; 
        } else {
          currentCell += char;
        }
      }
    }
    if (currentCell || currentRow.length > 0) {
      currentRow.push(currentCell.trim());
      rows.push(currentRow);
    }

    let gobIdx = 11, rentanIdx = 17, alqIdx = 23;
    let currentMunicipio = 'Desconocido';
    let currentFrente = 'Punto Crítico';
    const data = [];

    for(let i=2; i<rows.length; i++) {
       const row = rows[i];
       
       const municipio = row[2] ? row[2].trim() : '';
       const frente = row[3] ? row[3].trim() : '';

       if(municipio !== '') currentMunicipio = municipio;
       if(frente !== '') currentFrente = frente.replace(/[\r\n]+/g, ' '); 

       if(row.length < 8) continue; 
       
       const equipoRaw = row[7];
       if(!equipoRaw || equipoRaw.replace(/[^a-zA-Z0-9 ]/g, '').trim() === '') continue; 
       
       let equipo = equipoRaw.trim().toUpperCase();
       const serie = row[8] && row[8].replace(/[^a-zA-Z0-9 ]/g, '').trim() !== '' ? row[8].replace(/[^a-zA-Z0-9 ]/g, '').trim() : 'N/A';
       
       let owner = 'Alquilado'; 
       let count = 0;
       
       for(let c = 11; c < row.length; c++) {
          const val = row[c].trim().toLowerCase();
          const parsedInt = parseInt(val, 10);
          
          if(val === '1' || val === 'x' || (!isNaN(parsedInt) && parsedInt > 0)) {
             let qty = (!isNaN(parsedInt) && parsedInt > 0) ? parsedInt : 1;
             count += qty;
             if (gobIdx !== -1 && rentanIdx !== -1 && c >= gobIdx && c < rentanIdx) owner = 'Gobernación';
             else if (rentanIdx !== -1 && alqIdx !== -1 && c >= rentanIdx && c < alqIdx) owner = 'Rentan';
             else owner = 'Alquilado';
             
             for(let k=0; k<qty; k++) {
                 data.push({
                     municipio: currentMunicipio,
                     tipo: equipo,
                     placa: serie,
                     owner: owner
                 });
             }
             break; 
          }
       }
       
       if (count === 0) {
           data.push({
               municipio: currentMunicipio,
               tipo: equipo,
               placa: serie,
               owner: 'Alquilado'
           });
       }
    }

    const betulia = data.filter(d => d.municipio === 'BETULIA');
    console.log("BETULIA ITEMS:", betulia.length);
    console.dir(betulia);
  }

  processCSVImport(csvText);
