import re

with open('js/modules/frentes.js', 'r', encoding='utf-8') as f:
    text = f.read()

old_logic = """       if (colA.includes('EMERGENCIAS VIALES') || colB.includes('EMERGENCIAS VIALES') || colC.includes('EMERGENCIAS VIALES') || colD.includes('EMERGENCIAS VIALES')) {
           currentActivityType = 'Emergencias Viales';
       } else if (colA.includes('PUNTOS CRÍTICOS') || colA.includes('APC') || colB.includes('PUNTOS CRÍTICOS') || colC.includes('PUNTOS CRÍTICOS') || colD.includes('PUNTOS CRÍTICOS')) {
           currentActivityType = 'Atención a Puntos Críticos';
       }"""

new_logic = """       const removeAccents = (str) => str.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
       const colANorm = removeAccents(colA);
       const colBNorm = removeAccents(colB);
       const colCNorm = removeAccents(colC);
       const colDNorm = removeAccents(colD);

       if (colANorm.includes('EMERGENCIAS VIALES') || colBNorm.includes('EMERGENCIAS VIALES') || colCNorm.includes('EMERGENCIAS VIALES') || colDNorm.includes('EMERGENCIAS VIALES')) {
           currentActivityType = 'Emergencias Viales';
       } else if (colANorm.includes('PUNTOS CRITICOS') || colANorm.includes('APC') || colBNorm.includes('PUNTOS CRITICOS') || colCNorm.includes('PUNTOS CRITICOS') || colDNorm.includes('PUNTOS CRITICOS')) {
           currentActivityType = 'Atención a Puntos Críticos';
       }"""

# We also need to pre-scan rows 0 and 1 just in case they put the header in row 0 or 1.
old_prescan = """    let currentMunicipio = 'Desconocido';
    let currentFrente = 'Punto Crítico';
    let currentActivityType = 'Emergencias Viales';
    const data = [];
    const frenteMetadata = {};

    for(let i=2; i<rows.length; i++) {"""

new_prescan = """    let currentMunicipio = 'Desconocido';
    let currentFrente = 'Punto Crítico';
    let currentActivityType = 'Emergencias Viales';
    const data = [];
    const frenteMetadata = {};
    
    // Pre-scan row 0 and 1 for activity type just in case it's in A1 or A2
    const removeAccents = (str) => str.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
    for(let i=0; i<Math.min(2, rows.length); i++) {
       const r = rows[i];
       const cA = removeAccents((r[0] || '').toUpperCase());
       if (cA.includes('EMERGENCIAS VIALES')) currentActivityType = 'Emergencias Viales';
       else if (cA.includes('PUNTOS CRITICOS') || cA.includes('APC')) currentActivityType = 'Atención a Puntos Críticos';
    }

    for(let i=2; i<rows.length; i++) {"""

if old_logic in text and old_prescan in text:
    text = text.replace(old_logic, new_logic)
    text = text.replace(old_prescan, new_prescan)
    with open('js/modules/frentes.js', 'w', encoding='utf-8') as f:
        f.write(text)
    print("Patched activity type logic")
else:
    print("Failed to find logic blocks!")
