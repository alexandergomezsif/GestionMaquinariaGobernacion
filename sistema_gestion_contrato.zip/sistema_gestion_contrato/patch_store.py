﻿import json

with open('js/store.js', 'r', encoding='utf-8') as f:
    content = f.read()

# Replace initialization logic
init_logic_target = r"""  let currentState = JSON.parse(JSON.stringify(INITIAL_STATE));
  try {
    const saved = localStorage.getItem('AppStoreState');
    if (saved) {
      const parsed = JSON.parse(saved);
      currentState = Object.assign({}, INITIAL_STATE, parsed);
    }
  } catch(e) {}

  const listeners = [];

  function showDiscreetToast(msg) {
    let t = document.getElementById('auto-save-toast');
    if (!t) {
      t = document.createElement('div');
      t.id = 'auto-save-toast';
      t.style.cssText = 'position:fixed; bottom:20px; left:50%; transform:translateX(-50%); background:rgba(0,104,55,0.85); color:#fff; padding:6px 16px; border-radius:20px; font-size:0.75rem; z-index:9999; pointer-events:none; transition: opacity 0.5s; opacity:0; box-shadow: 0 2px 5px rgba(0,0,0,0.2);';
      document.body.appendChild(t);
    }
    t.textContent = msg;
    t.style.opacity = '1';
    setTimeout(() => { t.style.opacity = '0'; }, 2500);
  }

  setInterval(() => {
    try {
      localStorage.setItem('AppStoreState', JSON.stringify(currentState));
      showDiscreetToast('✓ Guardado automático completado');
    } catch(e) {}
  }, 45000);"""

new_init_logic = """  let currentState = JSON.parse(JSON.stringify(INITIAL_STATE));
  const listeners = [];
  let db;
  let fileHandle = null;
  let saveTimeout = null;

  const dbName = 'AppDB';
  const storeName = 'fileHandles';

  function initDB() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(dbName, 1);
      request.onupgradeneeded = (e) => {
        db = e.target.result;
        if (!db.objectStoreNames.contains(storeName)) {
          db.createObjectStore(storeName);
        }
      };
      request.onsuccess = (e) => {
        db = e.target.result;
        resolve(db);
      };
      request.onerror = (e) => reject(e);
    });
  }

  async function saveHandleToDB(handle) {
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, 'readwrite');
      const store = tx.objectStore(storeName);
      store.put(handle, 'mainDataFile');
      tx.oncomplete = () => resolve();
      tx.onerror = (e) => reject(e);
    });
  }

  async function getHandleFromDB() {
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, 'readonly');
      const store = tx.objectStore(storeName);
      const request = store.get('mainDataFile');
      request.onsuccess = () => resolve(request.result);
      request.onerror = (e) => reject(e);
    });
  }

  function updateSyncStatus(status) {
    let btn = document.getElementById('btn-sync-file');
    if (!btn) return;
    if (status === 'Guardado') {
      btn.innerHTML = '<span style="color:#16a34a;">●</span> ✓ Guardado en disco';
    } else if (status === 'Guardando...') {
      btn.innerHTML = '<span style="color:#eab308;">●</span> ⏳ Guardando...';
    } else if (status === 'Sin vincular') {
      btn.innerHTML = '<span style="color:#94a3b8;">●</span> 📁 Vincular archivo';
    } else if (status === 'Error') {
      btn.innerHTML = '<span style="color:#dc2626;">●</span> ❌ Error al guardar';
    } else if (status === 'Fallback') {
      btn.innerHTML = '<span style="color:#94a3b8;">●</span> 💾 Solo LocalStorage';
    }
  }

  async function verifyPermission(handle, readWrite) {
    const options = {};
    if (readWrite) options.mode = 'readwrite';
    if ((await handle.queryPermission(options)) === 'granted') return true;
    if ((await handle.requestPermission(options)) === 'granted') return true;
    return false;
  }

  async function loadDataFromFile() {
    try {
      const file = await fileHandle.getFile();
      const contents = await file.text();
      if (contents) {
        const parsed = JSON.parse(contents);
        currentState = Object.assign({}, INITIAL_STATE, parsed);
        notifySubscribers('StoreStateReplaced', currentState);
        updateSyncStatus('Guardado');
      }
    } catch (e) {
      console.error("Error leyendo archivo", e);
      updateSyncStatus('Error');
    }
  }

  async function writeDataToFile() {
    if (!fileHandle) return;
    try {
      updateSyncStatus('Guardando...');
      const writable = await fileHandle.createWritable();
      await writable.write(JSON.stringify(currentState, null, 2));
      await writable.close();
      updateSyncStatus('Guardado');
    } catch (e) {
      console.error("Error escribiendo archivo", e);
      updateSyncStatus('Error');
    }
  }

  function loadFallback() {
    try {
      const saved = localStorage.getItem('AppStoreState');
      if (saved) {
        const parsed = JSON.parse(saved);
        currentState = Object.assign({}, INITIAL_STATE, parsed);
        notifySubscribers('StoreStateReplaced', currentState);
      }
    } catch(e) {}
  }

  // Init DB and check handle
  initDB().then(async () => {
    fileHandle = await getHandleFromDB();
    if (fileHandle) {
      const hasPerm = await verifyPermission(fileHandle, true);
      if (hasPerm) {
        await loadDataFromFile();
      } else {
        loadFallback();
        updateSyncStatus('Sin vincular');
      }
    } else {
      loadFallback();
      updateSyncStatus('Sin vincular');
    }
  }).catch(e => {
    loadFallback();
    updateSyncStatus('Fallback');
  });"""

content = content.replace(init_logic_target, new_init_logic)

# Replace updateState logic
update_target = r"""    updateState(key, value, eventTopic = 'StoreUpdated') {
      currentState[key] = value;
      notifySubscribers(eventTopic, { key, value });
    },"""

new_update = """    updateState(key, value, eventTopic = 'StoreUpdated') {
      currentState[key] = value;
      notifySubscribers(eventTopic, { key, value });
      
      if (fileHandle && window.showSaveFilePicker) {
        if (saveTimeout) clearTimeout(saveTimeout);
        saveTimeout = setTimeout(() => {
          writeDataToFile();
        }, 500);
      } else {
        try { localStorage.setItem('AppStoreState', JSON.stringify(currentState)); } catch(e) {}
      }
    },"""
content = content.replace(update_target, new_update)

# Add linkDataFile function to return object
return_target = r"""  return {
    getState() {"""

new_return = """  return {
    async linkDataFile() {
      if (!window.showSaveFilePicker) {
        alert("Tu navegador no soporta File System Access API. Se usa LocalStorage automáticamente.");
        updateSyncStatus('Fallback');
        return;
      }
      try {
        if (fileHandle) {
          [fileHandle] = await window.showOpenFilePicker({
            types: [{ description: 'JSON Files', accept: { 'application/json': ['.json'] } }]
          });
        } else {
          fileHandle = await window.showSaveFilePicker({
            suggestedName: 'datos_app.json',
            types: [{ description: 'JSON Files', accept: { 'application/json': ['.json'] } }]
          });
        }
        await saveHandleToDB(fileHandle);
        
        // Always try to load if they pick an existing file, else write current state to new file
        try {
            const file = await fileHandle.getFile();
            if(file.size > 0) {
               await loadDataFromFile();
            } else {
               await writeDataToFile();
            }
        } catch(e) {
            await writeDataToFile();
        }
        
      } catch (e) {
        console.log("Picker cancelado", e);
      }
    },

    getState() {"""
content = content.replace(return_target, new_return)

with open('js/store.js', 'w', encoding='utf-8') as f:
    f.write(content)
