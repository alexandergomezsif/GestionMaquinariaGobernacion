import re

with open('js/modules/frentes.js', 'r', encoding='utf-8') as f:
    text = f.read()

# 1. Update processCSVImport
# Find the start of the data loop
loop_start = "let currentFrente = 'Punto Crítico';"
new_loop_start = """let currentFrente = 'Punto Crítico';
    let currentActivityType = 'Emergencias Viales';"""

if loop_start in text:
    text = text.replace(loop_start, new_loop_start)

loop_inside = """       const municipio = row[2] ? row[2].trim() : '';"""
new_loop_inside = """       const colA = (row[0] || '').toUpperCase();
       const colB = (row[1] || '').toUpperCase();
       const colC = (row[2] || '').toUpperCase();
       const colD = (row[3] || '').toUpperCase();
       
       if (colA.includes('EMERGENCIAS VIALES') || colB.includes('EMERGENCIAS VIALES') || colC.includes('EMERGENCIAS VIALES') || colD.includes('EMERGENCIAS VIALES')) {
           currentActivityType = 'Emergencias Viales';
       } else if (colA.includes('PUNTOS CRÍTICOS') || colA.includes('APC') || colB.includes('PUNTOS CRÍTICOS') || colC.includes('PUNTOS CRÍTICOS') || colD.includes('PUNTOS CRÍTICOS')) {
           currentActivityType = 'Atención a Puntos Críticos';
       }

       const municipio = row[2] ? row[2].trim() : '';"""

if loop_inside in text:
    text = text.replace(loop_inside, new_loop_inside)

assign_metadata = """if(!frenteMetadata[key]) {
          frenteMetadata[key] = { estadoVia: '', avance: '', longitud: '', km: '' };
       }"""
new_assign_metadata = """if(!frenteMetadata[key]) {
          frenteMetadata[key] = { estadoVia: '', avance: '', longitud: '', km: '', activityType: currentActivityType };
       }"""

if assign_metadata in text:
    text = text.replace(assign_metadata, new_assign_metadata)

assign_metadata_final = """f: fKey.split(' - ')[1],
          equipment: frentesMap[fKey],
          metadata: frenteMetadata[fKey]
        });"""
new_assign_metadata_final = """f: fKey.split(' - ')[1],
          equipment: frentesMap[fKey],
          metadata: frenteMetadata[fKey],
          activityType: frenteMetadata[fKey].activityType
        });"""

if assign_metadata_final in text:
    text = text.replace(assign_metadata_final, new_assign_metadata_final)


# 2. Update renderFrenteCard
render_card_old = """function renderFrenteCard(frente) {
    const eqPropios = frente.equipment.filter(e => (e.owner || '').toLowerCase().includes('gobernaci') || (e.owner || '').toLowerCase().includes('propio'));
    const eqRentan = frente.equipment.filter(e => (e.owner || '').toLowerCase().includes('rentan'));
    const eqAlquilados = frente.equipment.filter(e => !(e.owner || '').toLowerCase().includes('gobernaci') && !(e.owner || '').toLowerCase().includes('propio') && !(e.owner || '').toLowerCase().includes('rentan'));

    return `
      <div class="card" style="display: flex; flex-direction: column; box-shadow: var(--shadow-md);">
        <div style="border-bottom: 2px solid var(--card-border); padding-bottom: 10px; margin-bottom: 10px;">
          <div style="display:flex; justify-content:space-between; align-items:flex-start;">
            <h3 style="margin: 0; color: var(--primary-dark); font-size: 1.1rem; line-height: 1.2;">
              📍 ${window.AppHelpers.escapeHTML(frente.municipality)}
            </h3>"""

render_card_new = """function renderFrenteCard(frente) {
    const eqPropios = frente.equipment.filter(e => (e.owner || '').toLowerCase().includes('gobernaci') || (e.owner || '').toLowerCase().includes('propio'));
    const eqRentan = frente.equipment.filter(e => (e.owner || '').toLowerCase().includes('rentan'));
    const eqAlquilados = frente.equipment.filter(e => !(e.owner || '').toLowerCase().includes('gobernaci') && !(e.owner || '').toLowerCase().includes('propio') && !(e.owner || '').toLowerCase().includes('rentan'));

    const actType = frente.activityType || 'Emergencias Viales';
    const actIcon = actType === 'Emergencias Viales' ? 'icono-emergencias.png' : 'icono-puntos.png';
    const actColor = actType === 'Emergencias Viales' ? '#dc2626' : '#ca8a04';

    // Agrupar equipos por nombre para los iconos superiores
    const eqGroups = {};
    frente.equipment.forEach(e => {
        const type = window.AppHelpers.escapeHTML(e.type);
        if(!eqGroups[type]) eqGroups[type] = 0;
        eqGroups[type]++;
    });
    
    let eqSummaryHtml = '<div style="display:flex; flex-wrap:wrap; gap:8px; margin-top: 10px; margin-bottom: 5px;">';
    for(const [type, count] of Object.entries(eqGroups)) {
        eqSummaryHtml += `
            <div style="display:flex; align-items:center; background:#f1f5f9; padding:3px 6px; border-radius:4px; border:1px solid #e2e8f0;" title="${type}">
                ${window.AppHelpers.getEquipmentIcon(type, 18)} 
                <span style="font-weight:bold; font-size:0.8rem; color:var(--primary-dark);">x${count}</span>
            </div>
        `;
    }
    eqSummaryHtml += '</div>';

    return `
      <div class="card" style="display: flex; flex-direction: column; box-shadow: var(--shadow-md); border-top: 4px solid ${actColor};">
        <div style="border-bottom: 2px solid var(--card-border); padding-bottom: 10px; margin-bottom: 10px;">
          <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 8px;">
            <div style="display:flex; align-items:center; color:${actColor}; font-weight:bold; font-size:0.75rem; text-transform:uppercase;">
                <img src="img/${actIcon}" style="width:20px; height:20px; margin-right:6px; object-fit:contain;" alt="Icon">
                ${actType}
            </div>
            <span style="background: #f1f5f9; color: #475569; padding: 2px 6px; border-radius: 4px; font-size: 0.7rem; font-weight: bold;">
              ${frente.date || window.AppHelpers.getFormattedCurrentDate()}
            </span>
          </div>
          <div style="display:flex; justify-content:space-between; align-items:flex-start;">
            <h3 style="margin: 0; color: var(--primary-dark); font-size: 1.1rem; line-height: 1.2;">
              📍 ${window.AppHelpers.escapeHTML(frente.municipality)}
            </h3>
          </div>"""

if render_card_old in text:
    text = text.replace(render_card_old, render_card_new)

insert_summary_old = """${window.AppHelpers.escapeHTML(frente.name)}
          </div>"""
insert_summary_new = """${window.AppHelpers.escapeHTML(frente.name)}
          </div>
          ${eqSummaryHtml}"""

if insert_summary_old in text:
    text = text.replace(insert_summary_old, insert_summary_new)

# 3. Update loadActiveFrentesMarkers
marker_old = """const el = document.createElement('div');
                            el.className = 'frente-marker';
                            el.style.width = '28px';
                            el.style.height = '28px';
                            el.style.backgroundColor = 'white';
                            el.style.border = '2px solid var(--primary-dark)';
                            el.style.borderRadius = '50%';
                            el.style.boxShadow = '0 2px 6px rgba(0,0,0,0.4)';
                            el.style.cursor = 'pointer';
                            el.style.display = 'flex';
                            el.style.alignItems = 'center';
                            el.style.justifyContent = 'center';
                            el.innerHTML = '<img src="img/excavator.png" style="width:18px; height:18px; object-fit:contain;" alt="Frente">';"""

marker_new = """const el = document.createElement('div');
                            const actType = matchedFrente.activityType || 'Emergencias Viales';
                            const actIcon = actType === 'Emergencias Viales' ? 'icono-emergencias.png' : 'icono-puntos.png';
                            const actColor = actType === 'Emergencias Viales' ? '#dc2626' : '#ca8a04';
                            
                            el.className = 'frente-marker';
                            el.style.width = '32px';
                            el.style.height = '32px';
                            el.style.backgroundColor = 'white';
                            el.style.border = `2px solid ${actColor}`;
                            el.style.borderRadius = '50%';
                            el.style.boxShadow = '0 2px 6px rgba(0,0,0,0.4)';
                            el.style.cursor = 'pointer';
                            el.style.display = 'flex';
                            el.style.alignItems = 'center';
                            el.style.justifyContent = 'center';
                            el.innerHTML = `<img src="img/${actIcon}" style="width:22px; height:22px; object-fit:contain;" alt="Frente">`;"""

if marker_old in text:
    text = text.replace(marker_old, marker_new)
else:
    # If they still have the old one
    marker_old_2 = """const el = document.createElement('div');
                            el.className = 'frente-marker';
                            el.style.width = '24px';
                            el.style.height = '24px';
                            el.style.backgroundColor = 'var(--primary-dark)';
                            el.style.border = '2px solid white';
                            el.style.borderRadius = '50%';
                            el.style.boxShadow = '0 2px 5px rgba(0,0,0,0.3)';
                            el.style.cursor = 'pointer';
                            el.style.display = 'flex';
                            el.style.alignItems = 'center';
                            el.style.justifyContent = 'center';
                            el.style.color = 'white';
                            el.style.fontSize = '12px';
                            el.innerHTML = '<i class="ti ti-backhoe"></i>';"""
    if marker_old_2 in text:
        text = text.replace(marker_old_2, marker_new)

popup_old = """const popupHtml = `
                            <div style="font-family:sans-serif;font-size:0.8rem;color:#333; min-width: 180px;">
                              <h4 style="margin:0 0 5px;color:var(--primary-dark);">${window.AppHelpers.escapeHTML(matchedFrente.name)}</h4>
                              <div style="font-size: 0.7rem; color: #666; margin-bottom: 8px;">
                                📍 ${window.AppHelpers.escapeHTML(matchedFrente.municipality)}
                              </div>
                              <div style="background: #f1f5f9; padding: 6px; border-radius: 4px;">
                                <div><strong>Equipos Operando:</strong> <span style="font-size:1.1em; color:var(--primary-green); font-weight:bold;">${totalEq}</span></div>
                                ${matchedFrente.metadata && matchedFrente.metadata.estadoVia ? `<div><strong>Estado:</strong> ${window.AppHelpers.escapeHTML(matchedFrente.metadata.estadoVia)}</div>` : ''}
                                ${matchedFrente.metadata && matchedFrente.metadata.avance ? `<div><strong>Avance:</strong> ${window.AppHelpers.escapeHTML(matchedFrente.metadata.avance)}</div>` : ''}
                              </div>
                            </div>
                          `;"""

popup_new = """let eqIconsHtml = '<div style="display:flex; flex-wrap:wrap; gap:2px; margin-top:5px;">';
                          if (matchedFrente.equipment) {
                             matchedFrente.equipment.forEach(e => {
                                 eqIconsHtml += window.AppHelpers.getEquipmentIcon(e.type, 16);
                             });
                          }
                          eqIconsHtml += '</div>';

                          const popupHtml = `
                            <div style="font-family:sans-serif;font-size:0.8rem;color:#333; min-width: 180px;">
                              <div style="display:flex; align-items:center; color:${actColor}; font-weight:bold; font-size:0.7rem; text-transform:uppercase; margin-bottom:4px;">
                                  <img src="img/${actIcon}" style="width:14px; height:14px; margin-right:4px; object-fit:contain;" alt="Icon">
                                  ${actType}
                              </div>
                              <h4 style="margin:0 0 5px;color:var(--primary-dark);">${window.AppHelpers.escapeHTML(matchedFrente.name)}</h4>
                              <div style="font-size: 0.7rem; color: #666; margin-bottom: 8px;">
                                📍 ${window.AppHelpers.escapeHTML(matchedFrente.municipality)}
                              </div>
                              <div style="background: #f1f5f9; padding: 6px; border-radius: 4px;">
                                <div><strong>Equipos Operando:</strong> <span style="font-size:1.1em; color:var(--primary-green); font-weight:bold;">${totalEq}</span></div>
                                ${eqIconsHtml}
                                ${matchedFrente.metadata && matchedFrente.metadata.estadoVia ? `<div style="margin-top:6px;"><strong>Estado:</strong> ${window.AppHelpers.escapeHTML(matchedFrente.metadata.estadoVia)}</div>` : ''}
                                ${matchedFrente.metadata && matchedFrente.metadata.avance ? `<div><strong>Avance:</strong> ${window.AppHelpers.escapeHTML(matchedFrente.metadata.avance)}</div>` : ''}
                              </div>
                            </div>
                          `;"""

if popup_old in text:
    text = text.replace(popup_old, popup_new)
else:
    # try another old popup variant
    popup_old_2 = """const popupHtml = `
                            <div style="font-family:sans-serif;font-size:0.8rem;color:#333; min-width: 180px;">
                              <h4 style="margin:0 0 5px;color:var(--primary-dark);">${window.AppHelpers.escapeHTML(matchedFrente.name)}</h4>
                              <div style="font-size: 0.7rem; color: #666; margin-bottom: 8px;">
                                📍 ${window.AppHelpers.escapeHTML(matchedFrente.municipality)}
                              </div>
                              <div style="background: #f1f5f9; padding: 6px; border-radius: 4px;">
                                <div><strong>Equipos Operando:</strong> <span style="font-size:1.1em; color:var(--primary-green); font-weight:bold;">${totalEq}</span></div>
                                ${matchedFrente.metadata && matchedFrente.metadata.avance ? `<div><strong>Avance:</strong> ${window.AppHelpers.escapeHTML(matchedFrente.metadata.avance)}</div>` : ''}
                                ${matchedFrente.metadata && matchedFrente.metadata.estadoVia ? `<div><strong>Estado:</strong> ${window.AppHelpers.escapeHTML(matchedFrente.metadata.estadoVia)}</div>` : ''}
                              </div>
                            </div>
                          `;"""
    if popup_old_2 in text:
        text = text.replace(popup_old_2, popup_new)

with open('js/modules/frentes.js', 'w', encoding='utf-8') as f:
    f.write(text)
print("frentes.js patched")
