const fs = require('fs');

function processCSVImport(csvText) {
    const delimiter = csvText.split(/[\r\n]+/)[0].includes(';') ? ';' : ',';
    const rows = [];
    let currentRow = [];
    let currentCell = '';
    let inQuotes = false;

    for (let i = 0; i < csvText.length; i++) {
      const char = csvText[i];
      const nextChar = csvText[i+1];

      if (inQuotes) {
        if (char === '"' && nextChar === '"') {
          currentCell += '"';
          i++; 
        } else if (char === '"') {
          inQuotes = false;
        } else {
          currentCell += char;
        }
      } else {
        if (char === '"') {
          inQuotes = true;
        } else if (char === delimiter) {
          currentRow.push(currentCell.trim());
          currentCell = '';
        } else if (char === '\n' || (char === '\r' && nextChar === '\n')) {
          currentRow.push(currentCell.trim());
          rows.push(currentRow);
          currentRow = [];
          currentCell = '';
          if (char === '\r') i++; 
        } else {
          currentCell += char;
        }
      }
    }
    if (currentCell || currentRow.length > 0) {
      currentRow.push(currentCell.trim());
      rows.push(currentRow);
    }

    if (rows.length < 3) {
      console.log("El archivo CSV no tiene suficientes datos.");
      return;
    }

    let gobIdx = -1, rentanIdx = -1, alqIdx = -1;
    for(let i=0; i<rows[0].length; i++){
       const h = rows[0][i].toUpperCase();
       if(h.includes('GOB')) gobIdx = i;
       if(h.includes('RENTAN')) rentanIdx = i;
       if(h.includes('ALQUILADOS')) alqIdx = i;
    }
    
    if(gobIdx === -1) gobIdx = 11;
    if(rentanIdx === -1) rentanIdx = 17;
    if(alqIdx === -1) alqIdx = 23;

    let currentMunicipio = 'Desconocido';
    let currentFrente = 'Punto Crítico';
    let currentActivityType = 'Emergencias Viales';
    const data = [];
    const frenteMetadata = {};
    
    // Pre-scan row 0 and 1 for activity type just in case it's in A1 or A2
    const removeAccents = (str) => str.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
    for(let i=0; i<Math.min(2, rows.length); i++) {
       const r = rows[i];
       const cA = removeAccents((r[0] || '').toUpperCase());
       if (cA.includes('EMERGENCIAS VIALES')) currentActivityType = 'Emergencias Viales';
       else if (cA.includes('PUNTOS CRITICOS') || cA.includes('APC')) currentActivityType = 'Atención a Puntos Críticos';
    }

    for(let i=2; i<rows.length; i++) {
       const row = rows[i];
       
       const colA = (row[0] || '').toUpperCase();
       const colB = (row[1] || '').toUpperCase();
       const colC = (row[2] || '').toUpperCase();
       const colD = (row[3] || '').toUpperCase();
       
       const colANorm = removeAccents(colA);
       const colBNorm = removeAccents(colB);
       const colCNorm = removeAccents(colC);
       const colDNorm = removeAccents(colD);

       if (colANorm.includes('EMERGENCIAS VIALES') || colBNorm.includes('EMERGENCIAS VIALES') || colCNorm.includes('EMERGENCIAS VIALES') || colDNorm.includes('EMERGENCIAS VIALES')) {
           currentActivityType = 'Emergencias Viales';
       } else if (colANorm.includes('PUNTOS CRITICOS') || colANorm.includes('APC') || colBNorm.includes('PUNTOS CRITICOS') || colCNorm.includes('PUNTOS CRITICOS') || colDNorm.includes('PUNTOS CRITICOS')) {
           currentActivityType = 'Atención a Puntos Críticos';
       }

       const municipio = row[2] ? row[2].trim() : '';
       const frente = row[3] ? row[3].trim() : '';

       if(municipio !== '') currentMunicipio = municipio;
       if(frente !== '') currentFrente = frente.replace(/[\r\n]+/g, ' '); 

       const key = currentMunicipio.toUpperCase() + " - " + currentFrente.toUpperCase();
       if(!frenteMetadata[key]) {
          frenteMetadata[key] = { estadoVia: '', avance: '', longitud: '', km: '', activityType: currentActivityType };
       }

       const obsKey = (row[9] || '').trim();
       const obsVal = (row[10] || '').trim();
       if (obsKey && obsVal) {
           const kLower = obsKey.toLowerCase();
           if (kLower.includes('estado via') || kLower.includes('estado vía') || kLower.includes('estado de la via')) frenteMetadata[key].estadoVia = obsVal;
           else if (kLower.includes('avance')) frenteMetadata[key].avance = obsVal;
           else if (kLower.includes('longitud')) frenteMetadata[key].longitud = obsVal;
           else if (kLower.includes('km de atencion') || kLower.includes('km de atención')) frenteMetadata[key].km = obsVal;
       }

       if(row.length < 8) continue; 
       
       const equipoRaw = row[7];
       if(!equipoRaw || equipoRaw.replace(/[^a-zA-Z0-9 ]/g, '').trim() === '') continue; 
       
       let equipo = equipoRaw.trim().toUpperCase();
       if(equipo === 'RT') equipo = 'RETROEXCAVADORA';
       else if(equipo === 'VQ DT') equipo = 'VOLQUETA DOBLETROQUE';
       else if(equipo === 'EXC 13T') equipo = 'EXCAVADORA 13 TONELADAS';
       else if(equipo === 'EXC 20T') equipo = 'EXCAVADORA 20 TONELADAS';
       else if(equipo === 'MINI C' || equipo === 'MINI CARG') equipo = 'MINICARGADOR';
       else if(equipo === 'VQ SENC' || equipo === 'VQ SC') equipo = 'VOLQUETA SENCILLA';
       else if(equipo === 'VB' || equipo === 'VB 7T' || equipo === 'VB 10T') equipo = 'VIBROCOMPACTADOR';
       else if(equipo === 'BULL' || equipo === 'BULLD') equipo = 'BULLDOZER';
       else if(equipo === 'MT') equipo = 'MOTONIVELADORA';

       let owner = 'Alquilado'; 
       let count = 0;
       
       for(let c = 11; c < row.length; c++) {
          const val = (row[c] || '').trim().toLowerCase();
          const parsedInt = parseInt(val, 10);
          
          if(val === '1' || val === 'x' || (!isNaN(parsedInt) && parsedInt > 0)) {
             let qty = (!isNaN(parsedInt) && parsedInt > 0) ? parsedInt : 1;
             count += qty;
             if (gobIdx !== -1 && rentanIdx !== -1 && c >= gobIdx && c < rentanIdx) owner = 'Gobernación';
             else if (rentanIdx !== -1 && alqIdx !== -1 && c >= rentanIdx && c < alqIdx) owner = 'Rentan';
             else owner = 'Alquilado';
             
             for(let k=0; k<qty; k++) {
                 data.push({
                     municipio: currentMunicipio,
                     frente: currentFrente,
                     tipo: equipo,
                     placa: 'N/A',
                     owner: owner,
                     status: 'Operativo'
                 });
             }
          }
       }
    }

    console.log("Total frentes:", Object.keys(frenteMetadata).length);
    console.log("Total equipos:", data.length);
}

// Read CSV
const csv = fs.readFileSync('C:/Users/SuperUsuario/.gemini/antigravity/brain/5acee68c-ce2e-411b-b641-a7919144e3d0/.user_uploaded/media__1785442623753.csv', 'utf8');

// Simulate prepending EMERGENCIAS VIALES
const modifiedCsv = "EMERGENCIAS VIALES;;;;;;;;;;;;;;;;;;;;;\n" + csv;

console.log("Processing Original CSV");
processCSVImport(csv);

console.log("Processing Modified CSV");
processCSVImport(modifiedCsv);
