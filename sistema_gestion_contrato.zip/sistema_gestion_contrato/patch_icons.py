import sys
import re
import os

# Tabler Icons mapping
icon_map = {
    'fa fa-bars': 'ti ti-menu-2',
    'fa fa-home': 'ti ti-home',
    'fa fa-map-marked-alt': 'ti ti-map-2',
    'fa fa-search': 'ti ti-search',
    'fa fa-file-excel': 'ti ti-file-spreadsheet',
    'fa fa-plus': 'ti ti-plus',
    'fa fa-spinner': 'ti ti-loader',
    'fa-spin': 'ti-spin',
    'fa fa-file-pdf': 'ti ti-file-type-pdf',
    'fa fa-calendar': 'ti ti-calendar',
    'fa fa-bell': 'ti ti-bell',
    'fa fa-user-circle': 'ti ti-user-circle',
    'fa fa-tools': 'ti ti-tools',
    'fa fa-hard-hat': 'ti ti-backhoe',
    'fas fa-cogs': 'ti ti-settings',
    'fa fa-cogs': 'ti ti-settings',
    'fa fa-car-side': 'ti ti-truck',
    'fa fa-truck': 'ti ti-truck',
    'fa fa-car': 'ti ti-car',
    'fa fa-hammer': 'ti ti-hammer',
    'fa fa-wrench': 'ti ti-tool'
}

def replace_icons(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()

    # Replace FontAwesome CDN in index.html
    if 'font-awesome' in content or 'cdnjs.cloudflare.com/ajax/libs/font-awesome' in content:
        content = re.sub(
            r'<link[^>]*href="[^"]*font-awesome[^"]*"[^>]*>',
            '<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">',
            content
        )

    # Replace icon classes
    for fa, ti in icon_map.items():
        content = content.replace(fa, ti)

    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(content)

files_to_patch = [
    'index.html',
    'js/app.js',
    'js/modules/frentes.js'
]

for fp in files_to_patch:
    if os.path.exists(fp):
        replace_icons(fp)
        print(f"Patched {fp}")

# In css/modules.css, add .ti-spin if not natively supported by Tabler (it actually is not natively animated like fa-spin in the webfont).
# I'll just add it to css/modules.css
with open('css/modules.css', 'a', encoding='utf-8') as f:
    f.write('''
@keyframes ti-spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
.ti-spin {
  animation: ti-spin 2s linear infinite;
  display: inline-block;
}
''')
    print("Patched css/modules.css")
