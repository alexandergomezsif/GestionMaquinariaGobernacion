import sys
import re

with open('js/modules/frentes.js', 'r', encoding='utf-8') as f:
    content = f.read()

with open('frentes_parser_clean.js', 'r', encoding='utf-8') as f:
    new_func = f.read()

content = re.sub(r'  function renderFrenteCard\(frente\).*?  function generateFrentesPDF\(frentes\)', new_func + '\n\n  function generateFrentesPDF(frentes)', content, flags=re.DOTALL)

with open('js/modules/frentes.js', 'w', encoding='utf-8') as f:
    f.write(content)

print('Injected cleanly!')
