import sys

with open('js/modules/frentes.js', 'r', encoding='utf-8') as f:
    text = f.read()

old_block = """                            const el = document.createElement('div');
                            el.className = 'frente-marker';
                            el.style.width = '24px';
                            el.style.height = '24px';
                            el.style.backgroundColor = 'var(--primary-dark)';
                            el.style.border = '2px solid white';
                            el.style.borderRadius = '50%';
                            el.style.boxShadow = '0 2px 5px rgba(0,0,0,0.3)';
                            el.style.cursor = 'pointer';
                            el.style.display = 'flex';
                            el.style.alignItems = 'center';
                            el.style.justifyContent = 'center';
                            el.style.color = 'white';
                            el.style.fontSize = '12px';
                            el.innerHTML = '<i class="ti ti-backhoe"></i>';"""

new_block = """                            const el = document.createElement('div');
                            el.className = 'frente-marker';
                            el.style.width = '28px';
                            el.style.height = '28px';
                            el.style.backgroundColor = 'white';
                            el.style.border = '2px solid var(--primary-dark)';
                            el.style.borderRadius = '50%';
                            el.style.boxShadow = '0 2px 6px rgba(0,0,0,0.4)';
                            el.style.cursor = 'pointer';
                            el.style.display = 'flex';
                            el.style.alignItems = 'center';
                            el.style.justifyContent = 'center';
                            el.innerHTML = '<img src="img/excavator.png" style="width:18px; height:18px; object-fit:contain;" alt="Frente">';"""

if old_block in text:
    text = text.replace(old_block, new_block)
    with open('js/modules/frentes.js', 'w', encoding='utf-8') as f:
        f.write(text)
    print("Patched marker")
else:
    print("Failed to find marker code")
