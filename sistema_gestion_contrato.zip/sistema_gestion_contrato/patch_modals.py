with open('js/modules/informes.js', 'r', encoding='utf-8') as f:
    text = f.read()

# 1. Swap buttons and make the new one prominent
old_buttons = """        <div style="display: flex; gap: 10px;">
          <button class="btn btn-secondary" id="btn-add-report" style="background-color: var(--status-info); color: white; border: none;">
            📊 Registrar Flujo de Informe
          </button>
          <button class="btn btn-primary" id="btn-generate-acta">
            📝 Generador Automático de Actas
          </button>
        </div>"""

new_buttons = """        <div style="display: flex; gap: 10px;">
          <button class="btn btn-primary" id="btn-generate-acta" style="font-size: 1.1rem; padding: 10px 20px;">
            📝 Redactar y Generar Acta
          </button>
          <button class="btn btn-secondary" id="btn-add-report">
            📊 Registrar Flujo
          </button>
        </div>"""
text = text.replace(old_buttons, new_buttons)

# 2. Fix the modal HTML for Report Modal (Transparency issue)
old_report_modal = """    <div class="modal-overlay active" id="modal-report">
      <div class="modal-content">
        <div class="modal-header">
          <div class="modal-title">${isEdit ? '✏️ Editar Registro de Informe' : '📊 Registrar Nuevo Flujo de Informe'}</div>
          <button class="modal-close" id="modal-close-btn">&times;</button>
        </div>
        <form id="form-report">
          <div class="modal-body">"""

new_report_modal = """    <div class="modal-overlay active" id="modal-report">
      <form id="form-report" class="modal-content" style="background: white;">
        <div class="modal-header">
          <div class="modal-title">${isEdit ? '✏️ Editar Registro de Informe' : '📊 Registrar Nuevo Flujo de Informe'}</div>
          <button type="button" class="modal-close" id="modal-close-btn">&times;</button>
        </div>
        <div class="modal-body" style="background: white;">"""
text = text.replace(old_report_modal, new_report_modal)

old_report_footer = """          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" id="modal-cancel-btn">Cancelar</button>
            <button type="submit" class="btn btn-primary">${isEdit ? 'Guardar Cambios' : 'Registrar Informe'}</button>
          </div>
        </form>
      </div>
    </div>"""

new_report_footer = """          <div class="modal-footer" style="background: white;">
            <button type="button" class="btn btn-secondary" id="modal-cancel-btn">Cancelar</button>
            <button type="submit" class="btn btn-primary">${isEdit ? 'Guardar Cambios' : 'Registrar Informe'}</button>
          </div>
      </form>
    </div>"""
text = text.replace(old_report_footer, new_report_footer)

# Fix empty options in Report Modal
old_report_contract = """                <select id="rep-contract" class="form-control">
                  ${contracts.map(c => `<option value="${c.id}" ${isEdit && itemToEdit.contractId === c.id ? 'selected' : ''}>${c.number} - ${c.contractor}</option>`).join('')}
                </select>"""
new_report_contract = """                <select id="rep-contract" class="form-control">
                  <option value="">Seleccionar Contrato...</option>
                  <option value="NO_APLICA">No Aplica / General</option>
                  ${contracts.map(c => `<option value="${c.id}" ${isEdit && itemToEdit.contractId === c.id ? 'selected' : ''}>${c.number} - ${c.contractor}</option>`).join('')}
                </select>"""
text = text.replace(old_report_contract, new_report_contract)


# 3. Fix the modal HTML for Acta Generator Modal (Transparency issue)
old_acta_modal = """    <div class="modal-overlay active" id="modal-acta">
      <div class="modal-content" style="max-width: 800px;">
        <div class="modal-header">
          <div class="modal-title">📝 Generador Automático de Actas e Informes</div>
          <button class="modal-close" id="modal-close-acta">&times;</button>
        </div>
        <form id="form-acta">
          <div class="modal-body" style="max-height: 70vh; overflow-y: auto;">"""

new_acta_modal = """    <div class="modal-overlay active" id="modal-acta">
      <form id="form-acta" class="modal-content" style="max-width: 800px; background: white;">
        <div class="modal-header">
          <div class="modal-title">📝 Redactar y Generar Acta (Con Membretes)</div>
          <button type="button" class="modal-close" id="modal-close-acta">&times;</button>
        </div>
        <div class="modal-body" style="max-height: 70vh; overflow-y: auto; background: white;">"""
text = text.replace(old_acta_modal, new_acta_modal)

old_acta_footer = """          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" id="modal-cancel-acta">Cancelar</button>
            <button type="submit" class="btn btn-primary">📄 Generar y Guardar Oficial</button>
          </div>
        </form>
      </div>
    </div>"""

new_acta_footer = """          <div class="modal-footer" style="background: white;">
            <button type="button" class="btn btn-secondary" id="modal-cancel-acta">Cancelar</button>
            <button type="submit" class="btn btn-primary">📄 Generar e Imprimir Acta</button>
          </div>
      </form>
    </div>"""
text = text.replace(old_acta_footer, new_acta_footer)


with open('js/modules/informes.js', 'w', encoding='utf-8') as f:
    f.write(text)
print("Applied fixes to informes.js modals")
