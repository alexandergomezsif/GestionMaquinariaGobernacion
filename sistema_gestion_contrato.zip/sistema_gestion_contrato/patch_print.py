import re

with open('js/modules/informes.js', 'r', encoding='utf-8') as f:
    text = f.read()

old_script = """      <script>
        window.onload = function() {
          setTimeout(function() {
            window.print();
          }, 500);
        };
      <\\/script>
    </body>
    </html>
  `;

  const printWindow = window.open('', '_blank');
  printWindow.document.write(printHTML);
  printWindow.document.close();
}"""

new_script = """    </body>
    </html>
  `;

  const printWindow = window.open('', '_blank');
  printWindow.document.write(printHTML);
  printWindow.document.close();

  setTimeout(() => {
    printWindow.focus();
    printWindow.print();
  }, 500);
}"""

if old_script in text:
    text = text.replace(old_script, new_script)
else:
    # Try with raw backslash just in case
    old_script2 = """      <script>
        window.onload = function() {
          setTimeout(function() {
            window.print();
          }, 500);
        };
      <\/script>
    </body>
    </html>
  `;

  const printWindow = window.open('', '_blank');
  printWindow.document.write(printHTML);
  printWindow.document.close();
}"""
    if old_script2 in text:
        text = text.replace(old_script2, new_script)
    else:
        print("Warning: old script pattern not found in informes.js")

with open('js/modules/informes.js', 'w', encoding='utf-8') as f:
    f.write(text)

print("informes.js patched")
