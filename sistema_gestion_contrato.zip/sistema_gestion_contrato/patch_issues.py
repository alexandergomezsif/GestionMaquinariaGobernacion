import sys
import os

def patch_frentes():
    with open('js/modules/frentes.js', 'r', encoding='utf-8') as f:
        text = f.read()

    # Fix Marker syntax
    old_marker = "const marker = new maplibregl.Marker(el)"
    new_marker = "const marker = new maplibregl.Marker({ element: el })"
    if old_marker in text:
        text = text.replace(old_marker, new_marker)
    
    # Add ESC key listener if not already there
    if "e.key === 'Escape'" not in text:
        # I'll just append it to the map modal closing block
        old_close = """    const mapModalClose = document.getElementById('map-modal-close');
    if(mapModalClose) {
      mapModalClose.addEventListener('click', () => {
        document.getElementById('map-modal').classList.remove('active');
      });
    }"""
        new_close = """    const mapModalClose = document.getElementById('map-modal-close');
    const closeMapModal = () => {
        const modal = document.getElementById('map-modal');
        if (modal) modal.classList.remove('active');
    };
    if(mapModalClose) {
      mapModalClose.addEventListener('click', closeMapModal);
    }
    
    // ESC key listener for modal
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            closeMapModal();
        }
    });"""
        text = text.replace(old_close, new_close)

    with open('js/modules/frentes.js', 'w', encoding='utf-8') as f:
        f.write(text)
    print("frentes.js patched")

def patch_helpers():
    with open('js/utils/helpers.js', 'r', encoding='utf-8') as f:
        text = f.read()

    old_func = """    if (name.includes('excavadora') || name.includes('retroexcavadora') || name.includes('retrocargador') || name.includes('pajarita')) {
      return `<i class="ti ti-backhoe" style="${style}"></i>`;
    }
    
    if (name.includes('motoniveladora') || name.includes('niveladora')) {
      return `<i class="ti ti-tractor" style="${style}"></i>`;
    }"""
    
    new_func = """    if (name.includes('excavadora') || name.includes('retroexcavadora') || name.includes('retrocargador') || name.includes('pajarita')) {
      return `<i class="ti ti-backhoe" style="${style}"></i>`;
    }
    
    if (name.includes('motoniveladora') || name.includes('niveladora')) {
      return `<i class="ti ti-tractor" style="${style}"></i>`;
    }
    
    if (name.includes('vibrocompactador') || name.includes('compactador') || name.includes('rodillo')) {
      return `<i class="ti ti-tractor" style="${style}"></i>`;
    }"""
    
    if old_func in text:
        text = text.replace(old_func, new_func)
    
    with open('js/utils/helpers.js', 'w', encoding='utf-8') as f:
        f.write(text)
    print("helpers.js patched")

patch_frentes()
patch_helpers()
