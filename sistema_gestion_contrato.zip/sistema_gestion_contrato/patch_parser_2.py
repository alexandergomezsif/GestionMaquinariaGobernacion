import sys
import re

content = open('js/modules/frentes.js', 'r', encoding='utf-8').read()
new_func = open('frentes_parser.js', 'r', encoding='utf-8').read()

# The processCSVImport function starts with `  function processCSVImport(csvText) {`
# and ends right before `  function generateFrentesPDF(frentes) {`
content = re.sub(r'  function processCSVImport\(csvText\).*?  function generateFrentesPDF\(frentes\)', new_func + '\n\n  function generateFrentesPDF(frentes)', content, flags=re.DOTALL)

open('js/modules/frentes.js', 'w', encoding='utf-8').write(content)
print('Injected successfully!')
