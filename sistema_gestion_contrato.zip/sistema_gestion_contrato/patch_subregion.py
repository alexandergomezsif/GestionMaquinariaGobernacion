import re

with open('js/modules/frentes.js', 'r', encoding='utf-8') as f:
    text = f.read()

# 1. Add currentSubregion to initialization
old_init = """    let currentMunicipio = 'Desconocido';
    let currentFrente = 'Punto Crítico';
    let currentActivityType = 'Emergencias Viales';
    const data = [];
    const frenteMetadata = {};"""

new_init = """    let currentMunicipio = 'Desconocido';
    let currentSubregion = 'Desconocida';
    let currentFrente = 'Punto Crítico';
    let currentActivityType = 'Emergencias Viales';
    const data = [];
    const frenteMetadata = {};"""

text = text.replace(old_init, new_init)

# 2. Extract subregion and update frenteMetadata
old_extract = """       const municipio = row[2] ? row[2].trim() : '';
       const frente = row[3] ? row[3].trim() : '';

       if(municipio !== '') currentMunicipio = municipio;
       if(frente !== '') currentFrente = frente.replace(/[\\r\\n]+/g, ' '); 

       const key = currentMunicipio.toUpperCase() + " - " + currentFrente.toUpperCase();
       if(!frenteMetadata[key]) {
          frenteMetadata[key] = { estadoVia: '', avance: '', longitud: '', km: '', activityType: currentActivityType };
       }"""

new_extract = """       const isHeaderOrSection = colANorm.includes('EMERGENCIAS') || colANorm.includes('PUNTOS CRITICOS') || colANorm.includes('APC') || colANorm.includes('SUBREGION');
       if (!isHeaderOrSection && row[0] && row[0].trim() !== '') {
           currentSubregion = row[0].trim();
       }

       const municipio = row[2] ? row[2].trim() : '';
       const frente = row[3] ? row[3].trim() : '';

       if(municipio !== '') currentMunicipio = municipio;
       if(frente !== '') currentFrente = frente.replace(/[\\r\\n]+/g, ' '); 

       const key = currentMunicipio.toUpperCase() + " - " + currentFrente.toUpperCase();
       if(!frenteMetadata[key]) {
          frenteMetadata[key] = { estadoVia: '', avance: '', longitud: '', km: '', activityType: currentActivityType, subregion: currentSubregion };
       }"""

text = text.replace(old_extract, new_extract)

# 3. Add to grouped object
old_grouped = """          name: item.frente,
          date: window.AppHelpers.getFormattedCurrentDate(),
          metadata: frenteMetadata[key] || { estadoVia: '', avance: '', longitud: '', km: '' },
          activityType: frenteMetadata[key] ? frenteMetadata[key].activityType : 'Emergencias Viales',
          equipment: []"""

new_grouped = """          name: item.frente,
          date: window.AppHelpers.getFormattedCurrentDate(),
          metadata: frenteMetadata[key] || { estadoVia: '', avance: '', longitud: '', km: '', subregion: '' },
          activityType: frenteMetadata[key] ? frenteMetadata[key].activityType : 'Emergencias Viales',
          subregion: frenteMetadata[key] ? frenteMetadata[key].subregion : 'Desconocida',
          equipment: []"""

text = text.replace(old_grouped, new_grouped)

# 4. Render in the card
old_render = """          <h3 style="font-size: 1.1rem; color: var(--primary-dark); margin: 0 0 5px; font-weight: 700;">
            📍 ${window.AppHelpers.escapeHTML(frente.municipality)}
          </h3>"""

new_render = """          <h3 style="font-size: 1.1rem; color: var(--primary-dark); margin: 0 0 5px; font-weight: 700;">
            📍 ${window.AppHelpers.escapeHTML(frente.municipality)}
          </h3>
          <div style="font-size:0.75rem; color:#64748b; margin-top:-2px; margin-bottom:8px; font-weight:600; text-transform:uppercase;">
            🌎 Subregión: <span style="color:var(--primary-dark);">${window.AppHelpers.escapeHTML(frente.subregion || 'Desconocida')}</span>
          </div>"""

text = text.replace(old_render, new_render)

# Write back
with open('js/modules/frentes.js', 'w', encoding='utf-8') as f:
    f.write(text)
print("Patched subregion extraction and rendering")
