import sys
import re

with open('js/modules/frentes.js', 'r', encoding='utf-8') as f:
    text = f.read()

# Look for this exact block in the file
search_str = """                  // In a real app we'd wait for source.setData to finish or use idle event, simple timeout here
                  setTimeout(() => {
                    loaded++;
                    if(loaded === 3) loading.style.display = 'none';
                  }, 1500);
                });
              }
            });"""

replacement_str = """                  // In a real app we'd wait for source.setData to finish or use idle event, simple timeout here
                  setTimeout(() => {
                    loaded++;
                    if(loaded === 3) loading.style.display = 'none';
                  }, 1500);
                });
              }

              // NEW: Load Frentes Markers
              loadActiveFrentesMarkers();
            });

            // Keep track of markers to remove them if needed
            window.frentesMarkers = [];

            function loadActiveFrentesMarkers() {
              const frentes = window.AppStore.getState().frentesActivos || [];
              if (frentes.length === 0) return;

              // Extract codes
              const queries = [];
              const frentesMapByCode = {};

              frentes.forEach(f => {
                const parts = f.name.split(' ');
                // Guess code is the last part if it contains numbers and hyphens
                let code = parts[parts.length - 1];
                if (!/[0-9]/.test(code)) {
                  // Fallback: use the whole name as code query
                  code = f.name.trim();
                }
                
                // Add to where clause array
                queries.push(`CODIGO_VIA LIKE '%25${code}%25' OR NOMBRE_VIA LIKE '%25${code}%25'`);
                frentesMapByCode[code] = f;
              });

              // ArcGIS often limits where clauses. We can batch them.
              // For safety, let's just do a big OR query. If it fails, it fails gracefully.
              const chunkSize = 15;
              for (let i = 0; i < queries.length; i += chunkSize) {
                const chunk = queries.slice(i, i + chunkSize);
                const whereClause = chunk.join(' OR ');
                
                [1, 2, 3].forEach(layerIdx => {
                  const url = `https://services5.arcgis.com/K90UQIB09TmTjUL8/arcgis/rest/services/R10/FeatureServer/${layerIdx}/query?where=${whereClause}&outFields=*&f=geojson`;
                  
                  fetch(url).then(res => res.json()).then(data => {
                    if (data && data.features) {
                      data.features.forEach(feat => {
                        const props = feat.properties;
                        // Find matching frente
                        let matchedFrente = null;
                        let matchedCode = null;
                        for (let code in frentesMapByCode) {
                          if ((props.CODIGO_VIA && props.CODIGO_VIA.includes(code)) || 
                              (props.NOMBRE_VIA && props.NOMBRE_VIA.includes(code))) {
                            matchedFrente = frentesMapByCode[code];
                            matchedCode = code;
                            break;
                          }
                        }

                        if (matchedFrente && feat.geometry && feat.geometry.coordinates) {
                          // Approximate Centroid (take middle coordinate of first line segment)
                          let coords = feat.geometry.coordinates;
                          if (feat.geometry.type === 'MultiLineString') coords = coords[0];
                          if (!coords || coords.length === 0) return;
                          
                          const midIdx = Math.floor(coords.length / 2);
                          const center = coords[midIdx];

                          // Create Marker
                          const el = document.createElement('div');
                          el.className = 'frente-marker';
                          el.style.width = '24px';
                          el.style.height = '24px';
                          el.style.backgroundColor = 'var(--primary-dark)';
                          el.style.border = '2px solid white';
                          el.style.borderRadius = '50%';
                          el.style.boxShadow = '0 2px 5px rgba(0,0,0,0.3)';
                          el.style.cursor = 'pointer';
                          el.style.display = 'flex';
                          el.style.alignItems = 'center';
                          el.style.justifyContent = 'center';
                          el.style.color = 'white';
                          el.style.fontSize = '12px';
                          el.innerHTML = '<i class="fa fa-hard-hat"></i>';

                          const totalEq = matchedFrente.equipment.length;
                          const popupHtml = `
                            <div style="font-family:sans-serif;font-size:0.8rem;color:#333; min-width: 180px;">
                              <h4 style="margin:0 0 5px;color:var(--primary-dark);">${window.AppHelpers.escapeHTML(matchedFrente.name)}</h4>
                              <div style="font-size: 0.7rem; color: #666; margin-bottom: 8px;">
                                📍 ${window.AppHelpers.escapeHTML(matchedFrente.municipality)}
                              </div>
                              <div style="background: #f1f5f9; padding: 6px; border-radius: 4px;">
                                <div><strong>Equipos Operando:</strong> <span style="font-size:1.1em; color:var(--primary-green); font-weight:bold;">${totalEq}</span></div>
                                ${matchedFrente.metadata && matchedFrente.metadata.avance ? `<div><strong>Avance:</strong> ${window.AppHelpers.escapeHTML(matchedFrente.metadata.avance)}</div>` : ''}
                                ${matchedFrente.metadata && matchedFrente.metadata.estadoVia ? `<div><strong>Estado:</strong> ${window.AppHelpers.escapeHTML(matchedFrente.metadata.estadoVia)}</div>` : ''}
                              </div>
                            </div>
                          `;

                          const marker = new maplibregl.Marker(el)
                            .setLngLat(center)
                            .setPopup(new maplibregl.Popup({ offset: 15 }).setHTML(popupHtml))
                            .addTo(window.frentesMap);

                          window.frentesMarkers.push(marker);
                          
                          // Remove from dict so we don't place duplicate markers if it crosses layers
                          delete frentesMapByCode[matchedCode]; 
                        }
                      });
                    }
                  }).catch(e => console.error("Error fetching ArcGIS Layer", e));
                });
              }
            }"""

if search_str in text:
    text = text.replace(search_str, replacement_str)
    with open('js/modules/frentes.js', 'w', encoding='utf-8') as f:
        f.write(text)
    print("Patched successfully")
else:
    print("Could not find search string in frentes.js")
