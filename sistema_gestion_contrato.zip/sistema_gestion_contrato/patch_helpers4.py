import sys

with open('js/utils/helpers.js', 'r', encoding='utf-8') as f:
    text = f.read()

old_func = """  getEquipmentIcon(equipmentName) {
    if (!equipmentName) return '';
    const name = equipmentName.toLowerCase();
    
    const style = 'margin-right: 6px; vertical-align: middle; color: var(--primary-green); font-size: 1.2em;';
    
    if (name.includes('bulldozer') || name.includes('tractor')) {
      return `<i class="ti ti-bulldozer" style="${style}"></i>`;
    }
    
    if (name.includes('camabaja') || name.includes('trailer')) {
      return `<i class="ti ti-truck-loading" style="${style}"></i>`;
    }
    
    if (name.includes('volqueta') || name.includes('dump')) {
      return `<i class="ti ti-truck" style="${style}"></i>`;
    }
    
    if (name.includes('excavadora') || name.includes('retroexcavadora') || name.includes('retrocargador') || name.includes('pajarita')) {
      return `<i class="ti ti-backhoe" style="${style}"></i>`;
    }
    
    if (name.includes('motoniveladora') || name.includes('niveladora')) {
      return `<i class="ti ti-tractor" style="${style}"></i>`;
    }
    
    if (name.includes('vibrocompactador') || name.includes('compactador') || name.includes('rodillo')) {
      return `<i class="ti ti-tractor" style="${style}"></i>`;
    }
    
    // Default
    return `<i class="ti ti-tool" style="${style}"></i>`;
  }"""

new_func = """  getEquipmentIcon(equipmentName, size = 18) {
    if (!equipmentName) return '';
    const name = equipmentName.toLowerCase();
    const style = `width: ${size}px; height: ${size}px; object-fit: contain; vertical-align: middle; margin-right: 6px;`;
    let src = 'img/icon-excavadora.png'; // default
    
    if (name.includes('bulldozer') || name.includes('tractor')) src = 'img/icon-bulldozer.png';
    else if (name.includes('camabaja') || name.includes('trailer')) src = 'img/icon-camabaja.png';
    else if (name.includes('dobletroque')) src = 'img/icon-volqueta-dobletroque.png';
    else if (name.includes('volqueta') || name.includes('dump')) src = 'img/icon-volqueta-sencilla.png';
    else if (name.includes('retroexcavadora')) src = 'img/icon-retroexcavadora.png';
    else if (name.includes('retrocargador') || name.includes('pajarita')) src = 'img/icon-retrocargador.png';
    else if (name.includes('minicargador')) src = 'img/icon-minicargador.png';
    else if (name.includes('excavadora')) src = 'img/icon-excavadora.png';
    else if (name.includes('motoniveladora') || name.includes('niveladora')) src = 'img/icon-motoniveladora.png';
    else if (name.includes('vibrocompactador') || name.includes('compactador') || name.includes('rodillo')) src = 'img/icon-vibrocompactador.png';
    
    return `<img src="${src}" style="${style}" title="${window.AppHelpers.escapeHTML(equipmentName)}" alt="icon">`;
  }"""

if old_func in text:
    text = text.replace(old_func, new_func)
    with open('js/utils/helpers.js', 'w', encoding='utf-8') as f:
        f.write(text)
    print("Patched helpers.js")
else:
    print("Could not find old_func in helpers.js")
