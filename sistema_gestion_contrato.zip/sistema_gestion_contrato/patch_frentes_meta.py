import sys
import re

with open('js/modules/frentes.js', 'r', encoding='utf-8') as f:
    content = f.read()

new_render_and_process = """
  function renderFrenteCard(frente) {
    const eqPropios = frente.equipment.filter(e => (e.owner || '').toLowerCase().includes('gobernacion') || (e.owner || '').toLowerCase().includes('propio'));
    const eqAlquilados = frente.equipment.filter(e => !(e.owner || '').toLowerCase().includes('gobernacion') && !(e.owner || '').toLowerCase().includes('propio'));

    return `
      <div class="card" style="display: flex; flex-direction: column; box-shadow: var(--shadow-md);">
        <div style="border-bottom: 2px solid var(--card-border); padding-bottom: 10px; margin-bottom: 10px;">
          <div style="display:flex; justify-content:space-between; align-items:flex-start;">
            <h3 style="margin: 0; color: var(--primary-dark); font-size: 1.1rem; line-height: 1.2;">
              📍 ${window.AppHelpers.escapeHTML(frente.municipality)}
            </h3>
            <span style="background: #f1f5f9; color: #475569; padding: 2px 6px; border-radius: 4px; font-size: 0.7rem; font-weight: bold;">
              ${frente.date || window.AppHelpers.getFormattedCurrentDate()}
            </span>
          </div>
          <div style="font-size: 0.9rem; color: var(--text-secondary); margin-top: 4px; font-weight: 500;">
            ${window.AppHelpers.escapeHTML(frente.name)}
          </div>
          ${frente.metadata && (frente.metadata.estadoVia || frente.metadata.avance || frente.metadata.longitud || frente.metadata.km) ? `
          <div style="background: #f8fafc; border-radius: 4px; padding: 8px; margin-top: 8px; font-size: 0.75rem; color: var(--text-secondary);">
            ${frente.metadata.estadoVia ? `<div style="margin-bottom:2px;"><strong>🛣️ Estado:</strong> ${window.AppHelpers.escapeHTML(frente.metadata.estadoVia)}</div>` : ''}
            ${frente.metadata.avance ? `<div style="margin-bottom:2px;"><strong>📈 Avance:</strong> ${window.AppHelpers.escapeHTML(frente.metadata.avance)}</div>` : ''}
            ${frente.metadata.longitud ? `<div style="margin-bottom:2px;"><strong>📏 Longitud:</strong> ${window.AppHelpers.escapeHTML(frente.metadata.longitud)}</div>` : ''}
            ${frente.metadata.km ? `<div><strong>📍 Km Atención:</strong> ${window.AppHelpers.escapeHTML(frente.metadata.km)}</div>` : ''}
          </div>
          ` : ''}
        </div>

        <div style="flex-grow: 1;">
          <div style="display:flex; justify-content:space-between; font-size: 0.75rem; font-weight: bold; margin-bottom: 8px; color: var(--text-muted);">
            <span>TOTAL EQUIPOS: ${frente.equipment.length}</span>
            <span>
              <span style="color: var(--primary-green);">${eqPropios.length} Prop</span> | 
              <span style="color: var(--status-info);">${eqAlquilados.length} Alq</span>
            </span>
          </div>

          <ul style="list-style: none; padding: 0; margin: 0; display:flex; flex-direction:column; gap:6px;">
            ${frente.equipment.map(eq => {
              const isGobernacion = (eq.owner || '').toLowerCase().includes('gobernacion') || (eq.owner || '').toLowerCase().includes('propio');
              const tagColor = isGobernacion ? 'var(--primary-green)' : 'var(--status-info)';
              const ownerInitials = isGobernacion ? 'GOB' : 'RNT';

              return `
                <li style="display:flex; justify-content:space-between; align-items:center; background: #ffffff; padding: 6px 8px; border-radius: 4px; border-left: 3px solid ${tagColor}; border: 1px solid var(--card-border);">
                  <div style="display:flex; flex-direction:column; overflow:hidden;">
                    <span style="font-size: 0.75rem; font-weight: 700; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; color: var(--primary-dark);" title="${window.AppHelpers.escapeHTML(eq.type)}">
                      ${window.AppHelpers.getEquipmentIcon(eq.type)} ${window.AppHelpers.escapeHTML(eq.type)}
                    </span>
                    <span style="font-size: 0.7rem; color: var(--text-muted); margin-top: 1px;">Placa/Id: ${window.AppHelpers.escapeHTML(eq.plate || 'N/A')}</span>
                  </div>
                  <div style="display:flex; flex-direction:column; align-items:flex-end;">
                    <span style="font-size: 0.65rem; background: ${tagColor}; color: white; padding: 2px 4px; border-radius: 3px; font-weight:bold;">
                      ${ownerInitials}
                    </span>
                    <span style="font-size: 0.65rem; margin-top:2px; color: ${eq.status.toLowerCase().includes('operativo') ? 'var(--status-success)' : 'var(--status-danger)'};">
                      ${window.AppHelpers.escapeHTML(eq.status)}
                    </span>
                  </div>
                </li>
              `;
            }).join('')}
          </ul>
        </div>
      </div>
    `;
  }

  function processCSVImport(csvText) {
    const delimiter = csvText.split(/[\\r\\n]+/)[0].includes(';') ? ';' : ',';
    const rows = [];
    let currentRow = [];
    let currentCell = '';
    let inQuotes = false;

    for (let i = 0; i < csvText.length; i++) {
      const char = csvText[i];
      const nextChar = csvText[i+1];

      if (inQuotes) {
        if (char === '"' && nextChar === '"') {
          currentCell += '"';
          i++; 
        } else if (char === '"') {
          inQuotes = false;
        } else {
          currentCell += char;
        }
      } else {
        if (char === '"') {
          inQuotes = true;
        } else if (char === delimiter) {
          currentRow.push(currentCell.trim());
          currentCell = '';
        } else if (char === '\\n' || (char === '\\r' && nextChar === '\\n')) {
          currentRow.push(currentCell.trim());
          rows.push(currentRow);
          currentRow = [];
          currentCell = '';
          if (char === '\\r') i++; 
        } else {
          currentCell += char;
        }
      }
    }
    if (currentCell || currentRow.length > 0) {
      currentRow.push(currentCell.trim());
      rows.push(currentRow);
    }

    if (rows.length < 3) {
      alert("El archivo CSV no tiene suficientes datos.");
      return;
    }

    let gobIdx = -1, rentanIdx = -1, alqIdx = -1;
    for(let i=0; i<rows[0].length; i++){
       const h = rows[0][i].toUpperCase();
       if(h.includes('GOB')) gobIdx = i;
       if(h.includes('RENTAN')) rentanIdx = i;
       if(h.includes('ALQUILADOS')) alqIdx = i;
    }
    
    if(gobIdx === -1) gobIdx = 11;
    if(rentanIdx === -1) rentanIdx = 17;
    if(alqIdx === -1) alqIdx = 23;

    let currentMunicipio = 'Desconocido';
    let currentFrente = 'Punto Crítico';
    const data = [];
    const frenteMetadata = {};

    for(let i=2; i<rows.length; i++) {
       const row = rows[i];
       
       const municipio = row[2] ? row[2].trim() : '';
       const frente = row[3] ? row[3].trim() : '';

       if(municipio !== '') currentMunicipio = municipio;
       if(frente !== '') currentFrente = frente.replace(/[\\r\\n]+/g, ' '); 

       const key = currentMunicipio.toUpperCase() + " - " + currentFrente.toUpperCase();
       if(!frenteMetadata[key]) {
          frenteMetadata[key] = { estadoVia: '', avance: '', longitud: '', km: '' };
       }

       const obsKey = (row[9] || '').trim();
       const obsVal = (row[10] || '').trim();
       if (obsKey && obsVal) {
           const kLower = obsKey.toLowerCase();
           if (kLower.includes('estado via') || kLower.includes('estado vía') || kLower.includes('estado de la via')) frenteMetadata[key].estadoVia = obsVal;
           else if (kLower.includes('avance')) frenteMetadata[key].avance = obsVal;
           else if (kLower.includes('longitud')) frenteMetadata[key].longitud = obsVal;
           else if (kLower.includes('km de atencion') || kLower.includes('km de atención')) frenteMetadata[key].km = obsVal;
       }

       if(row.length < 8) continue; 
       
       const equipoRaw = row[7];
       if(!equipoRaw || equipoRaw.trim() === '') continue; 
       
       let equipo = equipoRaw.trim().toUpperCase();
       if(equipo === 'RT') equipo = 'RETROEXCAVADORA';
       else if(equipo === 'VQ DT') equipo = 'VOLQUETA DOBLETROQUE';
       else if(equipo === 'EXC 13T') equipo = 'EXCAVADORA 13 TONELADAS';
       else if(equipo === 'EXC 20T') equipo = 'EXCAVADORA 20 TONELADAS';
       else if(equipo === 'MINI C' || equipo === 'MINI CARG') equipo = 'MINICARGADOR';
       else if(equipo === 'VQ SENC' || equipo === 'VQ SC') equipo = 'VOLQUETA SENCILLA';
       else if(equipo === 'VB' || equipo === 'VB 7T' || equipo === 'VB 10T') equipo = 'VIBROCOMPACTADOR';
       else if(equipo === 'BULL' || equipo === 'BULLD') equipo = 'BULLDOZER';
       else if(equipo === 'MT') equipo = 'MOTONIVELADORA';

       const serie = row[8] && row[8].trim() !== '' ? row[8].trim() : 'N/A';
       
       let owner = 'Alquilado'; 
       let count = 0;
       
       for(let c = 11; c < row.length; c++) {
          const val = row[c].trim().toLowerCase();
          const parsedInt = parseInt(val, 10);
          
          if(val === '1' || val === 'x' || (!isNaN(parsedInt) && parsedInt > 0)) {
             let qty = (!isNaN(parsedInt) && parsedInt > 0) ? parsedInt : 1;
             count += qty;
             if (gobIdx !== -1 && rentanIdx !== -1 && c >= gobIdx && c < rentanIdx) owner = 'Gobernación';
             else if (rentanIdx !== -1 && alqIdx !== -1 && c >= rentanIdx && c < alqIdx) owner = 'Rentan';
             else owner = 'Alquilado';
             
             for(let k=0; k<qty; k++) {
                 data.push({
                     municipio: currentMunicipio,
                     frente: currentFrente,
                     tipo: equipo,
                     placa: qty > 1 && serie !== 'N/A' ? `${serie} (${k+1})` : serie,
                     owner: owner,
                     status: 'Operativo'
                 });
             }
             break; 
          }
       }
       
       if (count === 0) {
           data.push({
               municipio: currentMunicipio,
               frente: currentFrente,
               tipo: equipo,
               placa: serie,
               owner: 'Alquilado',
               status: 'Operativo'
           });
       }
    }

    if(data.length === 0) {
      alert("No se detectaron equipos. Por favor revisa el formato del archivo.");
      return;
    }

    const grouped = {};
    data.forEach(item => {
      const key = item.municipio.toUpperCase() + " - " + item.frente.toUpperCase();
      if (!grouped[key]) {
        grouped[key] = {
          id: window.AppHelpers.generateUUID(),
          municipality: item.municipio,
          name: item.frente,
          date: window.AppHelpers.getFormattedCurrentDate(),
          metadata: frenteMetadata[key] || { estadoVia: '', avance: '', longitud: '', km: '' },
          equipment: []
        };
      }
      grouped[key].equipment.push({
        type: item.tipo,
        plate: item.placa,
        owner: item.owner,
        status: item.status
      });
    });

    const frentesActivos = Object.values(grouped);
    
    if (confirm("Se han detectado " + frentesActivos.length + " frentes activos y " + data.length + " equipos. ¿Deseas reemplazar la base de datos actual?")) {
      window.AppStore.updateState('frentesActivos', frentesActivos);
      window.AppModules.frentesActivos(document.getElementById('app-main'));
    }
  }
"""

content = re.sub(r'  function renderFrenteCard\(frente\).*?  function generateFrentesPDF\(frentes\)', new_render_and_process + '\n\n  function generateFrentesPDF(frentes)', content, flags=re.DOTALL)

with open('js/modules/frentes.js', 'w', encoding='utf-8') as f:
    f.write(content)

print('Updated frentes.js successfully!')
