import re

with open('js/utils/helpers.js', 'r', encoding='utf-8') as f:
    text = f.read()

pattern = re.compile(r'getEquipmentIcon\(equipmentName\)\s*{.*?(?=\s*generateUUID\(\)\s*{)', re.DOTALL)

new_func = """getEquipmentIcon(equipmentName, size = 24) {
    if (!equipmentName) return '';
    const name = equipmentName.toLowerCase();
    const style = `width: ${size}px; height: ${size}px; object-fit: contain; vertical-align: middle; margin-right: 6px;`;
    let src = 'img/icon-excavadora.png'; // default
    
    if (name.includes('bulldozer') || name.includes('tractor')) src = 'img/icon-bulldozer.png';
    else if (name.includes('camabaja') || name.includes('trailer')) src = 'img/icon-camabaja.png';
    else if (name.includes('dobletroque')) src = 'img/icon-volqueta-dobletroque.png';
    else if (name.includes('volqueta') || name.includes('dump')) src = 'img/icon-volqueta-sencilla.png';
    else if (name.includes('retroexcavadora')) src = 'img/icon-retroexcavadora.png';
    else if (name.includes('retrocargador') || name.includes('pajarita')) src = 'img/icon-retrocargador.png';
    else if (name.includes('minicargador')) src = 'img/icon-minicargador.png';
    else if (name.includes('excavadora')) src = 'img/icon-excavadora.png';
    else if (name.includes('motoniveladora') || name.includes('niveladora')) src = 'img/icon-motoniveladora.png';
    else if (name.includes('vibrocompactador') || name.includes('compactador') || name.includes('rodillo')) src = 'img/icon-vibrocompactador.png';
    
    return `<img src="${src}" style="${style}" title="${window.AppHelpers.escapeHTML(equipmentName)}" alt="icon">`;
  }"""

text = re.sub(pattern, new_func + '\n\n  ', text)

with open('js/utils/helpers.js', 'w', encoding='utf-8') as f:
    f.write(text)
print("helpers.js patched")
