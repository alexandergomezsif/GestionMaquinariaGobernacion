import sys

with open('js/modules/frentes.js', 'r', encoding='utf-8') as f:
    text = f.read()

text = text.replace(".includes('gobernacion')", ".includes('gobernaci')")

with open('js/modules/frentes.js', 'w', encoding='utf-8') as f:
    f.write(text)

print('Patched PDF logic')
