import sys
import re

with open('js/modules/frentes.js', 'r', encoding='utf-8') as f:
    text = f.read()

# 1. Update filter bar to include map button and update legends
filter_bar_orig = """<span style="display:inline-block; width:12px; height:12px; background:var(--primary-green); border-radius:3px;"></span> Propios Gobernación
              <span style="display:inline-block; width:12px; height:12px; background:var(--status-info); border-radius:3px; margin-left: 10px;"></span> Alquilados Rentan"""
filter_bar_new = """<span style="display:inline-block; width:12px; height:12px; background:var(--primary-green); border-radius:3px;"></span> Gobernación
              <span style="display:inline-block; width:12px; height:12px; background:var(--status-info); border-radius:3px; margin-left: 10px;"></span> Rentan
              <span style="display:inline-block; width:12px; height:12px; background:var(--status-warning, #f59e0b); border-radius:3px; margin-left: 10px;"></span> Alquilados
              <button id="btn-open-map" class="btn btn-primary" style="margin-left: auto; padding: 4px 10px; font-size: 0.8rem;">
                <i class="fa fa-map-marked-alt"></i> Ver Mapa
              </button>"""
text = text.replace(filter_bar_orig, filter_bar_new)

# 2. Update equipment counts logic in renderFrenteCard
counts_orig = """const eqPropios = frente.equipment.filter(e => (e.owner || '').toLowerCase().includes('gobernaci') || (e.owner || '').toLowerCase().includes('propio'));
          const eqAlquilados = frente.equipment.filter(e => !(e.owner || '').toLowerCase().includes('gobernaci') && !(e.owner || '').toLowerCase().includes('propio'));"""
counts_new = """const eqPropios = frente.equipment.filter(e => (e.owner || '').toLowerCase().includes('gobernaci') || (e.owner || '').toLowerCase().includes('propio'));
          const eqRentan = frente.equipment.filter(e => (e.owner || '').toLowerCase().includes('rentan'));
          const eqAlquilados = frente.equipment.filter(e => !(e.owner || '').toLowerCase().includes('gobernaci') && !(e.owner || '').toLowerCase().includes('propio') && !(e.owner || '').toLowerCase().includes('rentan'));"""
text = text.replace(counts_orig, counts_new)

# 3. Update the badge rendering in renderFrenteCard
badges_orig = """<span class="badge ${eqPropios.length > 0 ? 'badge-success' : 'badge-secondary'}">${eqPropios.length} Prop</span> | <span class="badge ${eqAlquilados.length > 0 ? 'badge-info' : 'badge-secondary'}">${eqAlquilados.length} Alq</span>"""
badges_new = """<span class="badge ${eqPropios.length > 0 ? 'badge-success' : 'badge-secondary'}">${eqPropios.length} GOB</span> | <span class="badge ${eqRentan.length > 0 ? 'badge-info' : 'badge-secondary'}">${eqRentan.length} RNT</span> | <span class="badge ${eqAlquilados.length > 0 ? 'badge-warning' : 'badge-secondary'}" style="${eqAlquilados.length > 0 ? 'background-color:#f59e0b;' : ''}">${eqAlquilados.length} ALQ</span>"""
text = text.replace(badges_orig, badges_new)

# 4. Update the tag color rendering in renderFrenteCard
tag_orig = """const isGobernacion = (eq.owner || '').toLowerCase().includes('gobernaci') || (eq.owner || '').toLowerCase().includes('propio');
                const tagColor = isGobernacion ? 'var(--primary-green)' : 'var(--status-info)';
                const ownerInitials = isGobernacion ? 'GOB' : 'RNT';"""
tag_new = """const isGobernacion = (eq.owner || '').toLowerCase().includes('gobernaci') || (eq.owner || '').toLowerCase().includes('propio');
                const isRentan = (eq.owner || '').toLowerCase().includes('rentan');
                let tagColor = 'var(--status-warning, #f59e0b)';
                let ownerInitials = 'ALQ';
                if(isGobernacion) { tagColor = 'var(--primary-green)'; ownerInitials = 'GOB'; }
                else if(isRentan) { tagColor = 'var(--status-info)'; ownerInitials = 'RNT'; }"""
text = text.replace(tag_orig, tag_new)

# 5. Add afterRender logic for map
after_render_orig = """const searchInput = document.getElementById('frentes-search');
      if(searchInput) {"""
after_render_new = """
      const btnMap = document.getElementById('btn-open-map');
      if(btnMap) {
        btnMap.addEventListener('click', () => {
          const mapModal = document.getElementById('map-modal');
          if(mapModal) {
            mapModal.classList.add('active');
            if(!window.frentesMap && window.maplibregl) {
              window.frentesMap = new maplibregl.Map({
                container: 'map',
                style: 'https://basemaps.cartocdn.com/gl/positron-gl-style/style.json',
                center: [-75.5652, 6.2518], // Antioquia
                zoom: 6
              });
              window.frentesMap.addControl(new maplibregl.NavigationControl(), 'top-right');
            } else if(window.frentesMap) {
              setTimeout(() => window.frentesMap.resize(), 100);
            }
          }
        });
      }
      
      const mapModalClose = document.getElementById('map-modal-close');
      if(mapModalClose) {
        mapModalClose.addEventListener('click', () => {
          document.getElementById('map-modal').classList.remove('active');
        });
      }

      const searchInput = document.getElementById('frentes-search');
      if(searchInput) {"""
text = text.replace(after_render_orig, after_render_new)

# 6. Update generateFrentesPDF - CSS
pdf_css_orig = """.tag-gob { background-color: #16a34a; }
            .tag-rentan { background-color: #0284c7; }"""
pdf_css_new = """.tag-gob { background-color: #16a34a; }
            .tag-rentan { background-color: #0284c7; }
            .tag-alq { background-color: #f59e0b; }"""
text = text.replace(pdf_css_orig, pdf_css_new)

# 7. Update generateFrentesPDF - Box totals
pdf_boxes_orig = """<div class="summary-box">
              <div class="summary-value" style="color: #16a34a;">${totalPropios}</div>
              <div class="summary-label">Maquinaria Propia</div>
            </div>
            <div class="summary-box">
              <div class="summary-value" style="color: #0284c7;">${totalAlquilados}</div>
              <div class="summary-label">Maquinaria Alquilada</div>
            </div>"""
pdf_boxes_new = """<div class="summary-box">
              <div class="summary-value" style="color: #16a34a;">${totalPropios}</div>
              <div class="summary-label">Equipos Gobernación</div>
            </div>
            <div class="summary-box">
              <div class="summary-value" style="color: #0284c7;">${totalRentan}</div>
              <div class="summary-label">Equipos Rentan</div>
            </div>
            <div class="summary-box">
              <div class="summary-value" style="color: #f59e0b;">${totalAlquilados}</div>
              <div class="summary-label">Equipos Alquilados</div>
            </div>"""
text = text.replace(pdf_boxes_orig, pdf_boxes_new)

# 8. Update generateFrentesPDF - JS variables
pdf_vars_orig = """let totalFrentes = frentes.length;
      let totalEquipos = 0;
      let totalPropios = 0;
      let totalAlquilados = 0;
      
      frentes.forEach(f => {
        totalEquipos += f.equipment.length;
        f.equipment.forEach(eq => {
          const isGob = (eq.owner || '').toLowerCase().includes('gobernaci') || (eq.owner || '').toLowerCase().includes('propio');
          if(isGob) totalPropios++; else totalAlquilados++;
        });
      });"""
pdf_vars_new = """let totalFrentes = frentes.length;
      let totalEquipos = 0;
      let totalPropios = 0;
      let totalRentan = 0;
      let totalAlquilados = 0;
      
      frentes.forEach(f => {
        totalEquipos += f.equipment.length;
        f.equipment.forEach(eq => {
          const ownerLower = (eq.owner || '').toLowerCase();
          const isGob = ownerLower.includes('gobernaci') || ownerLower.includes('propio');
          const isRen = ownerLower.includes('rentan');
          if(isGob) totalPropios++; 
          else if(isRen) totalRentan++;
          else totalAlquilados++;
        });
      });"""
text = text.replace(pdf_vars_orig, pdf_vars_new)

# 9. Update generateFrentesPDF - Table rows
pdf_tr_orig = """const isGob = (eq.owner || '').toLowerCase().includes('gobernaci') || (eq.owner || '').toLowerCase().includes('propio');
                  rows += `<tr>
                    <td></td>
                    <td>${window.AppHelpers.escapeHTML(eq.type)}</td>
                    <td>${window.AppHelpers.escapeHTML(eq.plate || '-')}</td>
                    <td><span class="tag ${isGob ? 'tag-gob' : 'tag-rentan'}">${window.AppHelpers.escapeHTML(eq.owner)}</span></td>"""
pdf_tr_new = """const ownerLower = (eq.owner || '').toLowerCase();
                  const isGob = ownerLower.includes('gobernaci') || ownerLower.includes('propio');
                  const isRen = ownerLower.includes('rentan');
                  let tagClass = 'tag-alq';
                  if(isGob) tagClass = 'tag-gob';
                  else if(isRen) tagClass = 'tag-rentan';
                  
                  rows += `<tr>
                    <td></td>
                    <td>${window.AppHelpers.escapeHTML(eq.type)}</td>
                    <td>${window.AppHelpers.escapeHTML(eq.plate || '-')}</td>
                    <td><span class="tag ${tagClass}">${window.AppHelpers.escapeHTML(eq.owner)}</span></td>"""
text = text.replace(pdf_tr_orig, pdf_tr_new)


with open('js/modules/frentes.js', 'w', encoding='utf-8') as f:
    f.write(text)

print("Patch applied.")
