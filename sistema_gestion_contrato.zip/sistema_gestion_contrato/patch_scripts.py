import sys
content = open('index.html', 'r', encoding='utf-8').read()
idx = content.find('<script src="js/modules/informes.js"></script>')
if idx > 0:
    end_idx = content.find('</script>', idx) + 9
    new_item = '\n  <script src="js/modules/frentes.js"></script>'
    new_content = content[:end_idx] + new_item + content[end_idx:]
    open('index.html', 'w', encoding='utf-8').write(new_content)
    print('Injected script successfully!')
else:
    print('Script not found')
