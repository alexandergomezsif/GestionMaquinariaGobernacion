import re

def processCSVImport(csvText):
    delimiter = ';' if ';' in csvText.split('\n')[0] else ','
    rows = []
    currentRow = []
    currentCell = ''
    inQuotes = False
    
    for i in range(len(csvText)):
        char = csvText[i]
        nextChar = csvText[i+1] if i+1 < len(csvText) else ''
        
        if inQuotes:
            if char == '"' and nextChar == '"':
                currentCell += '"'
                # skipping next char is hard in simple loop, handled by char skipping in JS
            elif char == '"':
                inQuotes = False
            else:
                currentCell += char
        else:
            if char == '"':
                inQuotes = True
            elif char == delimiter:
                currentRow.append(currentCell.strip())
                currentCell = ''
            elif char == '\n' or (char == '\r' and nextChar == '\n'):
                currentRow.append(currentCell.strip())
                rows.append(currentRow)
                currentRow = []
                currentCell = ''
            else:
                if char != '\r':
                    currentCell += char

    if currentCell or len(currentRow) > 0:
        currentRow.append(currentCell.strip())
        rows.append(currentRow)
        
    if len(rows) < 3:
        print("El archivo CSV no tiene suficientes datos.")
        return
        
    print(f"Num rows: {len(rows)}")
    print(f"Row 0 length: {len(rows[0])}, Content: {rows[0][:5]}")
    if len(rows) > 3:
        print(f"Row 3 length: {len(rows[3])}, Content: {rows[3][:5]}")

with open('C:/Users/SuperUsuario/.gemini/antigravity/brain/5acee68c-ce2e-411b-b641-a7919144e3d0/.user_uploaded/media__1785442623753.csv', 'r', encoding='latin-1') as f:
    csv = f.read()

modifiedCsv = "EMERGENCIAS VIALES;;;;;;;;;;;;;;;;;;;;;\n" + csv
processCSVImport(modifiedCsv)
