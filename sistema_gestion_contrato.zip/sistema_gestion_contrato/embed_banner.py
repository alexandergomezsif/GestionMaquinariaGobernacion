import base64

with open('img/banner.png', 'rb') as f:
    b64 = base64.b64encode(f.read()).decode('utf-8')

with open('index.html', 'r', encoding='utf-8') as f:
    html = f.read()

html = html.replace("url('img/banner.png')", f"url('data:image/png;base64,{b64}')")

with open('index.html', 'w', encoding='utf-8') as f:
    f.write(html)
