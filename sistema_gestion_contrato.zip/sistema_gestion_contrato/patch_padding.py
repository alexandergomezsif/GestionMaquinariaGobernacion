import re

with open('js/modules/informes.js', 'r', encoding='utf-8') as f:
    text = f.read()

# Add margin-bottom to the fade-in div
text = text.replace('<div class="fade-in">', '<div class="fade-in" style="padding-bottom: 4rem;">')

with open('js/modules/informes.js', 'w', encoding='utf-8') as f:
    f.write(text)

print("informes.js patched")
