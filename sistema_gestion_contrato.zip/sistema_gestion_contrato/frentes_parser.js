  function processCSVImport(csvText) {
    const delimiter = csvText.split(/[\\r\\n]+/)[0].includes(';') ? ';' : ',';
    const rows = [];
    let currentRow = [];
    let currentCell = '';
    let inQuotes = false;

    for (let i = 0; i < csvText.length; i++) {
      const char = csvText[i];
      const nextChar = csvText[i+1];

      if (inQuotes) {
        if (char === '"' && nextChar === '"') {
          currentCell += '"';
          i++; 
        } else if (char === '"') {
          inQuotes = false;
        } else {
          currentCell += char;
        }
      } else {
        if (char === '"') {
          inQuotes = true;
        } else if (char === delimiter) {
          currentRow.push(currentCell.trim());
          currentCell = '';
        } else if (char === '\\n' || (char === '\\r' && nextChar === '\\n')) {
          currentRow.push(currentCell.trim());
          rows.push(currentRow);
          currentRow = [];
          currentCell = '';
          if (char === '\\r') i++; 
        } else {
          currentCell += char;
        }
      }
    }
    if (currentCell || currentRow.length > 0) {
      currentRow.push(currentCell.trim());
      rows.push(currentRow);
    }

    if (rows.length < 3) {
      alert("El archivo CSV no tiene suficientes datos.");
      return;
    }

    let gobIdx = -1, rentanIdx = -1, alqIdx = -1;
    for(let i=0; i<rows[0].length; i++){
       const h = rows[0][i].toUpperCase();
       if(h.includes('GOB')) gobIdx = i;
       if(h.includes('RENTAN')) rentanIdx = i;
       if(h.includes('ALQUILADOS')) alqIdx = i;
    }
    
    if(gobIdx === -1) gobIdx = 11;
    if(rentanIdx === -1) rentanIdx = 17;
    if(alqIdx === -1) alqIdx = 23;

    let currentMunicipio = 'Desconocido';
    let currentFrente = 'Punto Crítico';
    const data = [];

    for(let i=2; i<rows.length; i++) {
       const row = rows[i];
       if(row.length < 8) continue; 
       
       const equipo = row[7];
       if(!equipo || equipo.trim() === '') continue; 
       
       const municipio = row[2] ? row[2].trim() : '';
       const frente = row[3] ? row[3].trim() : '';

       if(municipio !== '') currentMunicipio = municipio;
       if(frente !== '') currentFrente = frente.replace(/[\\r\\n]+/g, ' '); 

       const serie = row[8] && row[8].trim() !== '' ? row[8].trim() : 'N/A';
       
       let owner = 'Alquilado'; 
       for(let c = 11; c < row.length; c++) {
          if(row[c] === '1' || row[c].toLowerCase() === 'x') {
             if (gobIdx !== -1 && rentanIdx !== -1 && c >= gobIdx && c < rentanIdx) owner = 'Gobernación';
             else if (rentanIdx !== -1 && alqIdx !== -1 && c >= rentanIdx && c < alqIdx) owner = 'Rentan';
             else owner = 'Alquilado';
             break;
          }
       }

       data.push({
         municipio: currentMunicipio,
         frente: currentFrente,
         tipo: equipo,
         placa: serie,
         owner: owner,
         status: 'Operativo'
       });
    }

    if(data.length === 0) {
      alert("No se detectaron equipos. Por favor revisa el formato del archivo.");
      return;
    }

    const grouped = {};
    data.forEach(item => {
      const key = item.municipio.toUpperCase() + " - " + item.frente.toUpperCase();
      if (!grouped[key]) {
        grouped[key] = {
          id: window.AppHelpers.generateUUID(),
          municipality: item.municipio,
          name: item.frente,
          date: window.AppHelpers.getFormattedCurrentDate(),
          equipment: []
        };
      }
      grouped[key].equipment.push({
        type: item.tipo,
        plate: item.placa,
        owner: item.owner,
        status: item.status
      });
    });

    const frentesActivos = Object.values(grouped);
    
    if (confirm("Se han detectado " + frentesActivos.length + " frentes activos y " + data.length + " equipos. ¿Deseas reemplazar la base de datos actual?")) {
      window.AppStore.updateState('frentesActivos', frentesActivos);
      window.AppModules.frentesActivos(document.getElementById('app-main'));
    }
  }
