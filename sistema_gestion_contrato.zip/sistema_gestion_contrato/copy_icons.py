import os
import shutil

src_dir = r"C:\Users\SuperUsuario\.gemini\antigravity\scratch\sistema_gestion_contrato\FentesActivos"
dest_dir = r"C:\Users\SuperUsuario\.gemini\antigravity\scratch\sistema_gestion_contrato\img"

mapping = {
    "1. BULLDOZER - copia.png": "icon-bulldozer.png",
    "2. RETROCARGADOR - copia.png": "icon-retrocargador.png",
    "3. MINICARGADOR - copia.png": "icon-minicargador.png",
    "4. VOLQUETA SENCILLA - copia.png": "icon-volqueta-sencilla.png",
    "5. VOLQUETA DOBLETROQUE - copia.png": "icon-volqueta-dobletroque.png",
    "6. CAMABAJA - copia.png": "icon-camabaja.png",
    "7. RETROEXCAVADORA - copia.png": "icon-retroexcavadora.png",
    "8. EXCAVADORA - copia.png": "icon-excavadora.png",
    "9. VIBROCOMPACTADOR - copia.png": "icon-vibrocompactador.png",
    "10. MOTONIVELADORA - copia.png": "icon-motoniveladora.png",
    "ICONO_EMERGENCIAS.png": "icono-emergencias.png",
    "ICONO_PUNTOS.png": "icono-puntos.png"
}

for src_name, dest_name in mapping.items():
    src_path = os.path.join(src_dir, src_name)
    dest_path = os.path.join(dest_dir, dest_name)
    if os.path.exists(src_path):
        shutil.copy(src_path, dest_path)
        print(f"Copied {src_name} to {dest_name}")
    else:
        print(f"File not found: {src_path}")
