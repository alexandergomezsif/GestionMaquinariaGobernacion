import re

with open('js/modules/informes.js', 'r', encoding='utf-8') as f:
    text = f.read()

# Add firma image definition
if "const firma = 'img/firmaalexgomez.png';" not in text:
    text = text.replace("const logoRentan = 'img/logorentan.png';", "const logoRentan = 'img/logorentan.png';\n  const firma = 'img/firmaalexgomez.png';")

# Add signature img in html
old_sig = """      <div class="signatures">
        <div class="signature-block">
          <div class="signature-line"></div>
          <strong>${window.AppHelpers.escapeHTML(acta.responsable)}</strong><br/>"""

new_sig = """      <div class="signatures">
        <div class="signature-block">
          <img src="${firma}" style="max-height: 100px; margin-bottom: -10px; display: block; margin-left: auto; margin-right: auto;" onerror="this.style.display='none';">
          <div class="signature-line"></div>
          <strong>${window.AppHelpers.escapeHTML(acta.responsable)}</strong><br/>"""

text = text.replace(old_sig, new_sig)

with open('js/modules/informes.js', 'w', encoding='utf-8') as f:
    f.write(text)

print("Signature added!")
