import sys

with open('frentes_parser_clean.js', 'r', encoding='utf-8') as f:
    text = f.read()

# Fix the 'gobernacion' match to handle accents
text = text.replace(".includes('gobernacion')", ".includes('gobernaci')")

# Fix the ghost equipment issue caused by empty characters
text = text.replace("if(!equipoRaw || equipoRaw.trim() === '') continue;", "if(!equipoRaw || equipoRaw.replace(/[^a-zA-Z0-9 ]/g, '').trim() === '') continue;")

# Clean the serie
text = text.replace("row[8] && row[8].trim() !== '' ? row[8].trim() : 'N/A'", "row[8] && row[8].replace(/[^a-zA-Z0-9 ]/g, '').trim() !== '' ? row[8].replace(/[^a-zA-Z0-9 ]/g, '').trim() : 'N/A'")

with open('frentes_parser_clean.js', 'w', encoding='utf-8') as f:
    f.write(text)

print('Patched frentes_parser_clean.js')
