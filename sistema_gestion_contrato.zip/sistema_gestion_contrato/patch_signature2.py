with open('js/modules/informes.js', 'r', encoding='utf-8') as f:
    text = f.read()

# Remove the field from the form
old_form_field = """            <div class="form-group">
              <label>Elaboró / Responsable (Firma)</label>
              <input type="text" id="acta-responsable" class="form-control" value="Alexander Gómez Avendaño - Secretario de Infraestructura" required />
            </div>"""
if old_form_field in text:
    text = text.replace(old_form_field, "")
else:
    print("Warning: old_form_field not found")

# Modify object creation to provide a default empty string just in case
old_obj_creation = "responsable: document.getElementById('acta-responsable').value.trim()"
new_obj_creation = "responsable: document.getElementById('acta-responsable') ? document.getElementById('acta-responsable').value.trim() : 'Alex Gómez'"
text = text.replace(old_obj_creation, new_obj_creation)

# Modify the signature block in HTML to only contain the image
old_sig_block = """      <div class="signatures">
        <div class="signature-block">
          <img src="${firma}" style="max-height: 100px; margin-bottom: -10px; display: block; margin-left: auto; margin-right: auto;" onerror="this.style.display='none';">
          <div class="signature-line"></div>
          <strong>${window.AppHelpers.escapeHTML(acta.responsable)}</strong><br/>
          <span style="font-size: 9pt; color: #64748b;">Elaboró / Responsable</span>
        </div>
      </div>"""

new_sig_block = """      <div class="signatures">
        <div class="signature-block" style="text-align: left;">
          <img src="${firma}" style="max-height: 150px; display: block;" onerror="this.style.display='none';">
        </div>
      </div>"""
text = text.replace(old_sig_block, new_sig_block)

# Try encoding issue fix for 'Elaboró' if it didn't match
old_sig_block_fallback = """      <div class="signatures">
        <div class="signature-block">
          <img src="${firma}" style="max-height: 100px; margin-bottom: -10px; display: block; margin-left: auto; margin-right: auto;" onerror="this.style.display='none';">
          <div class="signature-line"></div>
          <strong>${window.AppHelpers.escapeHTML(acta.responsable)}</strong><br/>
          <span style="font-size: 9pt; color: #64748b;">Elabor\u00f3 / Responsable</span>
        </div>
      </div>"""
text = text.replace(old_sig_block_fallback, new_sig_block)


with open('js/modules/informes.js', 'w', encoding='utf-8') as f:
    f.write(text)

print("informes.js patched")
