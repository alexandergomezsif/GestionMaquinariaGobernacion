import sys
content = open('js/modules/frentes.js', 'r', encoding='utf-8').read()
content = content.replace("split('\\\\n')", "split(/\\r?\\n/)")
open('js/modules/frentes.js', 'w', encoding='utf-8').write(content)
print('Fixed newline split')
