import base64
import re

with open('img/logogober.png', 'rb') as f:
    gober_b64 = base64.b64encode(f.read()).decode('utf-8')

with open('img/logorentan.png', 'rb') as f:
    rentan_b64 = base64.b64encode(f.read()).decode('utf-8')

with open('index.html', 'r', encoding='utf-8') as f:
    html = f.read()

new_header = f'''      <div class="header-brand" style="flex-grow: 1; display: flex; align-items: center; justify-content: space-between; padding: 5px 20px; margin-right: 15px; background: #ffffff; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
        <img src="data:image/png;base64,{gober_b64}" style="height: 70px; object-fit: contain;">
        <div class="header-titles" style="text-align: center; flex-grow: 1; padding: 0 15px;">
          <h1 style="color: var(--primary-dark); font-size: 1.3rem; margin-bottom: 2px;">GOBERNACIÓN DE ANTIOQUIA</h1>
          <h2 style="color: var(--text-primary); font-size: 0.95rem; margin-bottom: 2px;">Secretaría de Infraestructura Física</h2>
          <h3 style="color: var(--text-secondary); font-size: 0.85rem; font-weight: 500;">Dirección de Desarrollo Físico</h3>
        </div>
        <img src="data:image/png;base64,{rentan_b64}" style="height: 60px; object-fit: contain;">
      </div>'''

html = re.sub(r'<div class="header-brand"[\s\S]*?<div class="header-controls">', new_header + '\n\n      <div class="header-controls">', html)

with open('index.html', 'w', encoding='utf-8') as f:
    f.write(html)
