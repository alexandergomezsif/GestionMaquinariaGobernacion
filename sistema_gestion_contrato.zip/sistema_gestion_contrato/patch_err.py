import re

with open('js/modules/frentes.js', 'r', encoding='utf-8') as f:
    text = f.read()

old_err = """    if(data.length === 0) {
      alert("No se detectaron equipos. Por favor revisa el formato del archivo.");
      return;
    }"""

new_err = """    if(data.length === 0) {
      // Debug mode: show what the parser saw
      let debugStr = "No se detectaron equipos.\\nEstructura leída:\\n";
      for(let d=0; d<Math.min(5, rows.length); d++) {
         debugStr += `Fila ${d}: [${rows[d][7] || 'Vacio'}] Cols:${rows[d].length}\\n`;
      }
      alert(debugStr + "\\nPor favor asegúrate de que la columna H (8va columna) contenga el tipo de equipo, y que las cantidades estén desde la columna L (12va columna) en adelante.");
      return;
    }"""

if old_err in text:
    text = text.replace(old_err, new_err)
    with open('js/modules/frentes.js', 'w', encoding='utf-8') as f:
        f.write(text)
    print("Patched error message")
else:
    print("Failed to find error message block")
