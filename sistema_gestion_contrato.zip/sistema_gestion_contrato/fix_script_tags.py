with open('js/modules/informes.js', 'r', encoding='utf-8') as f:
    text = f.read()

text = text.replace('<script>', '<scr' + 'ipt>')
text = text.replace('</script>', '<\\/script>')

with open('js/modules/informes.js', 'w', encoding='utf-8') as f:
    f.write(text)
print("Escaped script tags in informes.js")
