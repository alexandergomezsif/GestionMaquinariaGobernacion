import sys
import re

with open('js/utils/helpers.js', 'r', encoding='utf-8') as f:
    text = f.read()

# I will replace the whole getEquipmentIcon function block
start_str = "getEquipmentIcon(equipmentName) {"
end_str = """    if (name.includes('retroexcavadora')) {
      return svgBase + `
        <rect x="5" y="15" width="12" height="4" rx="2" />
        <rect x="7" y="7" width="8" height="8" />
        <path d="M 11 11 L 19 3 L 23 9" stroke="currentColor" stroke-width="2.5" fill="none" stroke-linejoin="round" />
        <path d="M 23 9 L 18 14 L 24 14 Z" />
      </svg>`;
    }
    
    // Icono general por defecto
    return svgBase + `
      <rect x="3" y="15" width="18" height="4" rx="2" />
      <rect x="5" y="8" width="14" height="7" />
      <circle cx="8" cy="19" r="2" fill="currentColor"/>
      <circle cx="16" cy="19" r="2" fill="currentColor"/>
    </svg>`;
  }"""

new_func = """getEquipmentIcon(equipmentName) {
    if (!equipmentName) return '';
    const name = equipmentName.toLowerCase();
    
    const style = 'margin-right: 6px; vertical-align: middle; color: var(--primary-green); font-size: 1.2em;';
    
    if (name.includes('bulldozer') || name.includes('tractor')) {
      return `<i class="ti ti-bulldozer" style="${style}"></i>`;
    }
    
    if (name.includes('camabaja') || name.includes('trailer')) {
      return `<i class="ti ti-truck-loading" style="${style}"></i>`;
    }
    
    if (name.includes('volqueta') || name.includes('dump')) {
      return `<i class="ti ti-truck" style="${style}"></i>`;
    }
    
    if (name.includes('excavadora') || name.includes('retroexcavadora') || name.includes('retrocargador') || name.includes('pajarita')) {
      return `<i class="ti ti-backhoe" style="${style}"></i>`;
    }
    
    if (name.includes('motoniveladora') || name.includes('niveladora')) {
      return `<i class="ti ti-tractor" style="${style}"></i>`;
    }
    
    // Default
    return `<i class="ti ti-tool" style="${style}"></i>`;
  }"""

# Since I don't know the exact end string because I haven't seen lines 210 to 232, I will use regex.
pattern = re.compile(r'getEquipmentIcon\(equipmentName\)\s*{.*?(?=\s*generateUUID\(\)\s*{)', re.DOTALL)
text = re.sub(pattern, new_func + '\n\n  ', text)

with open('js/utils/helpers.js', 'w', encoding='utf-8') as f:
    f.write(text)
