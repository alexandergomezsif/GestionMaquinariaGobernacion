with open('js/modules/informes.js', 'r', encoding='utf-8') as f:
    text = f.read()

# Fix the escaped backticks and dollar signs
text = text.replace(r'\`', '`')
text = text.replace(r'\$', '$')

# Fix the double backslash in split
text = text.replace(r"split('\\n')", r"split('\n')")

with open('js/modules/informes.js', 'w', encoding='utf-8') as f:
    f.write(text)
print("Syntax errors fixed in informes.js")
